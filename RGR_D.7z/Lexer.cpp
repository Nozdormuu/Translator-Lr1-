#include "Lexer.h"

bool Check_Var_correct(string str)

{
    string mistake;
    for (size_t i = 0; i < str.size(); i++)
    {
        if (!(isdigit(str[i]) or (isalpha(str[i])))) {
            mistake += str[i];
        }
        if (mistake.size() >= 1) {
            cout << str << " in this var needs to delete  " << mistake << endl;
            return 0;

        }


    }
    return 1;

}

bool Check_BigNumber_correct(string str)

{
    string mistake;
    for (size_t i = 0; i < str.size(); i++) {
        if (!isdigit(str[i]) and (i >= 1)) {
            while (!isdigit(str[i]) and (i < str.size())) { mistake += str[i]; i++; }
            cout << str << "  " << mistake << "  Forbidden symbol(s) in BN!" << endl;;
            return 0;


        }

    }
    return 1;
}

bool Check_constant(string str)
{
    for (size_t i = 0; i < str.size(); i++) {
        if (!isdigit(str[i]))
            return 0;
    }
    return 1;
}

vector<Lexem_Token> Lexer(string filename)

{
    ifstream in(filename);
    string buff;
    vector<Lexem_Token> words;
    string str;

    vector<pair<size_t, string>> newStr;
    vector<pair<size_t, string>> copy;
    //getline(in, buff);
    size_t number_of_string = 1;

    while (getline(in, buff))
    {
        for (size_t i = 0; i < buff.size(); i++)
        {
            if (buff[i] != ' ')
            {
                str = str + buff[i];

                if ((buff[i + 1] == (' ')) or (buff[i + 1] == '\0'))
                {
                    newStr.push_back({ number_of_string,str });
                    str.clear();

                }

            }
        }
        number_of_string++;
    }
    /* for (auto i : newStr)
        cout << i.first <<" " <<i.second << endl;*/
    for (size_t i = 0; i < newStr.size(); i++)
    {
        copy.push_back(newStr[i]);
        if (newStr[i].second == string("<<<"))
        {
            while (newStr[i].second != string(">>>"))
            {
                ++i;
                if (i == newStr.size()) {
                    cout << "Comment is not closed" << " at string " << newStr[i - 1].first << endl;
                    copy.pop_back();
                    copy.push_back({ newStr[i - 1].first,string("Errorcomm") });
                    break;
                }
            }

        }

    }
    newStr = copy;
    /* cout << "After" << endl;
     for (auto i : newStr)
        cout << i.first << " " << i.second << endl;*/


    for (auto i : newStr)
    {
        if (i.second == string("Errorcomm"))
        {
            words.push_back(Lexem_Token(i.first, string("Error comment"), string("Error")));
            continue;

        }
        if (isdigit(i.second[0]) and (words[words.size() - 1].m_leks != string("jump")))
        {
            if (Check_constant(i.second))
            {
                words.push_back(Lexem_Token(i.first, i.second, string("Constant")));
                continue;
            }
            else
            {

                string str;
                size_t l = 0;
                for (size_t j = 0; j < i.second.size(); j++)
                {
                    if (isalpha(i.second[j]))
                        l++;
                }
                if (l == 0)
                {
                    for (size_t m = 0; m < i.second.size(); m++)
                    {
                        if (!isdigit(i.second[m])) {
                            str += i.second[m];
                        }

                    }
                    cout << "There is error in Constant with exists forbidden symbols" << "    " << i.second << "  " << str << " - it should be destroyed" << endl;
                    cout << "At " << i.first << " str" << endl;
                    words.push_back(Lexem_Token(i.first, string("Error in Constant"), string("Error")));
                    continue;


                }
                for (size_t c = 0; c < i.second.size(); ++c) {
                    if (isalpha(i.second[c]))
                        continue;
                    str += i.second[c];
                }
                cout << "There is error in m_type of Variable,it cannot begins on digit" << "    " << i.second << "  " << str << " - it should be destroyed" << endl;
                cout << "At " << i.first << " str" << endl;
                words.push_back(Lexem_Token(i.first, string("Error in Variable"), string("Error")));
                continue;
            }
        }

        if (i.second == string(";"))
        {
            words.push_back(Lexem_Token(i.first, string(";"), string("Semicolon")));
            continue;

        }
        if (i.second == string("in"))
        {
            words.push_back(Lexem_Token(i.first, string("in"), string("in")));
            continue;

        }
        if (i.second == string("if"))
        {
            words.push_back(Lexem_Token(i.first, string("if"), string("if")));
            continue;

        }
        if (i.second == string("else"))
        {
            words.push_back(Lexem_Token(i.first, string("else"), string("else")));
            continue;

        }
        if (i.second == string("od"))
        {
            words.push_back(Lexem_Token(i.first, string("od"), string("od")));
            continue;

        }
        if (i.second == string("from"))
        {
            words.push_back(Lexem_Token(i.first, string("from"), string("from")));
            continue;

        }
        if (i.second == string("by"))
        {
            words.push_back(Lexem_Token(i.first, string("by"), string("by")));
            continue;

        }
        if (i.second == string("case"))
        {
            words.push_back(Lexem_Token(i.first, string("case"), string("case")));
            continue;

        }
        if (i.second == string("select"))
        {
            words.push_back(Lexem_Token(i.first, string("select"), string("select")));
            continue;

        }
        if (i.second == string("("))
        {
            words.push_back(Lexem_Token(i.first, string("("), string("Left_Br")));
            continue;

        }
        if (i.second == string(")"))
        {
            words.push_back(Lexem_Token(i.first, string(")"), string("Right_Br")));
            continue;

        }

        if (i.second == string("ni"))
        {
            words.push_back(Lexem_Token(i.first, string("ni"), string("ni")));
            continue;

        }
        if (i.second == string("fi"))
        {
            words.push_back(Lexem_Token(i.first, string("fi"), string("fi")));
            continue;

        }
        if (i.second == string("while"))
        {
            words.push_back(Lexem_Token(i.first, string("while"), string("while")));
            continue;

        }
        if (i.second == string("do"))
        {
            words.push_back(Lexem_Token(i.first, string("do"), string("do")));
            continue;

        }
        if (i.second == string("+"))
        {
            words.push_back(Lexem_Token(i.first, string("+"), string("AR_OP")));
            continue;

        }
        if (((i.second[0] == '+') or (i.second[0] == '-') or (i.second[0] == '*') or (i.second[0] == '/') or (i.second[0] == '%')) and (i.second.size() > 1))
        {
            cout << i.second << "  This arithm operation not exists!" << "Error at string  " << i.first << endl;
            string sr;
            for (size_t k = 1; k < i.second.size(); k++) {
                sr += i.second[k];
            }
            cout << "It should delete " << sr << endl;
            words.push_back(Lexem_Token(i.first, string("Ar_Error"), string("Error")));
            continue;

        }
        if (((i.second[0] == '>') or (i.second[0] == '<') or (i.second[0] == '=') or (i.second[0] == '!')) and (i.second[1] != '=') and (i.second.size() > 1))
        {
            if (i.second == string("<<<"))
            {
                words.push_back(Lexem_Token(i.first, string("<<<"), string("Comma")));
                continue;
            }
            cout << i.second << "  This order operation not exists!" << "Error at string  " << i.first << endl;
            string sr;
            for (size_t k = 1; k < i.second.size(); k++) {
                sr += i.second[k];
            }
            cout << "It should delete " << sr << endl;
            words.push_back(Lexem_Token(i.first, string("Order_Error"), string("Error")));
            continue;

        }

        if (((i.second[0] == '>') or (i.second[0] == '<') or (i.second[0] == '=') or (i.second[0] == '!')) and (i.second[1] == '=') and (i.second.size() > 2))
        {
            if (i.second == string("<<<"))
            {
                words.push_back(Lexem_Token(i.first, string("<<<"), string("Comma")));
                continue;
            }
            string sr;
            for (size_t k = 2; k < i.second.size(); k++) {
                sr += i.second[k];
            }

            cout << i.second << "  This order operation not exists!" << "Error at string  " << i.first << endl;
            cout << "It should delete " << sr << endl;
            words.push_back(Lexem_Token(i.first, string("Order_Error"), string("Error")));
            continue;

        }


        if (i.second == string("-"))
        {
            words.push_back(Lexem_Token(i.first, string("-"), string("AR_OP")));
            continue;

        }
        if (i.second == string("/"))
        {
            words.push_back(Lexem_Token(i.first, string("/"), string("AR_OP")));
            continue;

        }
        if (i.second == string(","))
        {
            words.push_back(Lexem_Token(i.first, string(","), string("Sep")));
            continue;

        }
        if (i.second == string("="))
        {
            words.push_back(Lexem_Token(i.first, string("="), string("Prisv")));
            continue;

        }
        if (i.second == string("otherwise"))
        {
            words.push_back(Lexem_Token(i.first, string("otherwise"), string("otherwise")));
            continue;

        }
        if (i.second == string("from"))
        {
            words.push_back(Lexem_Token(i.first, string("from"), string("from")));
            continue;

        }
        if (i.second == string("for"))
        {
            words.push_back(Lexem_Token(i.first, string("for"), string("for")));
            continue;

        }
        if (i.second == string("to"))
        {
            words.push_back(Lexem_Token(i.first, string("to"), string("to")));
            continue;

        }
        if (i.second == string("input"))
        {
            words.push_back(Lexem_Token(i.first, string("input"), string("input")));
            continue;
        }
        if (i.second == string("throw"))
        {
            words.push_back(Lexem_Token(i.first, string("throw"), string("exception")));
            continue;
        }

        if (i.second == string("print"))
        {
            words.push_back(Lexem_Token(i.first, string("print"), string("print")));
            continue;

        }

        if (i.second == string("%"))
        {
            words.push_back(Lexem_Token(i.first, string("%"), string("AR_OP")));
            continue;

        }
        if (i.second == string(">"))
        {
            words.push_back(Lexem_Token(i.first, string(">"), string("Order")));
            continue;

        }
        if (i.second == string("<"))
        {
            words.push_back(Lexem_Token(i.first, string("<"), string("Order")));
            continue;

        }
        if (i.second == string(">="))
        {
            words.push_back(Lexem_Token(i.first, string(">="), string("Order")));
            continue;

        }
        if (i.second == string("<="))
        {
            words.push_back(Lexem_Token(i.first, string("<="), string("Order")));
            continue;

        }
        if (i.second == string("!="))
        {
            words.push_back(Lexem_Token(i.first, string("!="), string("Order")));
            continue;

        }
        if (i.second == string("=="))
        {
            words.push_back(Lexem_Token(i.first, string("=="), string("Order")));
            continue;

        }
        if (i.second == string("digit"))
        {
            words.push_back(Lexem_Token(i.first, string("digit"), string("BigNumberOp")));
            continue;

        }
        if (i.second == string("umn"))
        {
            words.push_back(Lexem_Token(i.first, string("umn"), string("BigNumberOp")));
            continue;

        }
        if (i.second == string("del"))
        {
            words.push_back(Lexem_Token(i.first, string("del"), string("BigNumberOp")));
            continue;

        }
        if (i.second == string("mod"))
        {
            words.push_back(Lexem_Token(i.first, string("mod"), string("BigNumberOp")));
            continue;

        }
        if (i.second == string("plus"))
        {
            words.push_back(Lexem_Token(i.first, string("plus"), string("BigNumberOp")));
            continue;

        }
        if (i.second == string("mns"))
        {
            words.push_back(Lexem_Token(i.first, string("mns"), string("BigNumberOp")));
            continue;

        }
        if (i.second == string("*"))
        {
            words.push_back(Lexem_Token(i.first, string("*"), string("AR_OP")));
            continue;

        }

        if ((i.second == string(":")) and (i.second.size() == 1))
        {
            words.push_back(Lexem_Token(i.first, string(":"), string("Twocolon")));
            continue;

        }
        if ((i.second == string("jump")))
        {
            words.push_back(Lexem_Token(i.first, string("jump"), string("jump")));
            continue;

        }

        if ((i.second[0] == ':') and (i.second.size() > 1))
        {
            words.push_back(Lexem_Token(i.first, i.second, string("Label")));
            continue;

        }
        if ((i.second == string("BigNumber")))
        {
            words.push_back(Lexem_Token(i.first, string("BigNumber"), string("Type")));
            continue;

        }
        if (i.second == string("int"))
        {
            words.push_back(Lexem_Token(i.first, string("int"), string("Type")));
            continue;

        }
        if (i.second == string("<<<"))
        {
            words.push_back(Lexem_Token(i.first, string("<<<"), string("Comma")));
            continue;


        }

        if ((i.second[0] == '[') and (i.second.size() > 1))
        {
            if (Check_BigNumber_correct(i.second))
            {
                words.push_back(Lexem_Token(i.first, i.second, string("BNConstant")));
                continue;

            }
            else
            {
                words.push_back(Lexem_Token(i.first, string("Error in BigNumber!It contains forbidden symbol"), string("Error")));
                cout << "At  " << i.first << "  str" << endl;
                continue;

            }
        }
        if (words.size() > 1) {
            if (words[words.size() - 1].m_leks == string("jump"))
            {
                words.push_back(Lexem_Token(i.first, i.second, string("Label")));
                continue;

            }
        }
        if (isalpha(i.second[0]))
        {
            if (Check_Var_correct(i.second)) {
                words.push_back(Lexem_Token(i.first, i.second, string("Var")));
                continue;
            }
            words.push_back(Lexem_Token(i.first, string("Error in var"), string("Error")));
            continue;


        }

        else
        {
            bool t = 0;
            bool e = 0;
            string mistake;


            for (size_t k = 0; k < i.second.size(); k++)
            {

                if (isalpha(i.second[k]))
                {
                    for (size_t g = 0; g < i.second.size(); g++) {
                        if (g < k)
                        {
                            mistake += i.second[g];
                            continue;
                        }
                        if (isdigit(i.second[g]) or isalpha(i.second[g]))
                            continue;
                        mistake += i.second[g];

                    }
                    break;
                }

            }
            if (mistake.size() != 0)
            {
                cout << "Should be deleted  " << mistake << "  in var  " << i.second << " at string  " << i.first << endl;
                words.push_back(Lexem_Token(i.first, string("Error Vars"), string("Error")));
                continue;
            }

            for (size_t k = 0; k < i.second.size(); k++)
            {

                if (isdigit(i.second[k]))
                {
                    for (size_t g = 0; g < i.second.size(); g++) {
                        if (g < k)
                        {
                            mistake += i.second[g];
                            continue;
                        }
                        if (isdigit(i.second[g]))
                        {
                            continue;
                        }
                        mistake += i.second[g];

                    }
                    break;

                }
            }
            //cout << endl << endl << mistake << endl << endl;
            if (mistake.size() != 0)
            {
                cout << "Should be deleted  " << mistake << "  in constant  " << i.second << " at string  " << i.first << endl;
                words.push_back(Lexem_Token(i.first, string("Error const"), string("Error")));
                continue;
            }



            cout << "Error  lexema it cannot exists in this language " << i.second << endl << "In string " << i.first << endl;
            words.push_back(Lexem_Token(i.first, string("Error"), string("Error")));
            continue;
        }

    }
    /*cout << "Number" << "     " << "Type" << "     " << "Lexem" << endl;
    for (auto i : words)
       cout << i.m_line << "     " << i.m_type << "          " << i.m_leks << endl;*/

    words.push_back(Lexem_Token(words.back().m_line + 1, string("EOL"), string("EOL")));
    return words;
}
