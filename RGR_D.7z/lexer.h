#pragma once
#include "Base.h"

bool Check_Var_correct(string str);

bool Check_BigNumber_correct(string str);

bool Check_constant(string str);

vector <Lexem_Token> Lexer(string filename);


