#pragma once
#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <string>
using namespace std;

struct Lexem_Token
{
    size_t m_line;
    string m_type;
    string m_leks;
    Lexem_Token() { ; }
    Lexem_Token(size_t m_m_line, string m_lexem, string m_name)
    {
        m_line = m_m_line;
        m_type = m_name;
        m_leks = m_lexem;
    }

};