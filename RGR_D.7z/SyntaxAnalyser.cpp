#include "SyntaxAnalyser.h"

Synt::Synt() {}
