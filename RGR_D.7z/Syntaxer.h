#pragma once
#include "Base.h"

class Syntaxer
{
public:
    bool Start(vector<Lexem_Token>& leks)
    {
        // �����
        pos = 0;
        check_op = 0;
        put_depth = 0;
        synt_depth = 0;
        m_lexem.clear();
        // �����
        m_marks.clear();
        // �������� ���������
        exp_count = 0;
        depth = 0;
        brac = 0;
        hash_depth = 0;
        hash_read = 0;
        hash_brac = 0;
        g_exp_count = 0;
        m_get_exp.clear();
        m_temp_exp.clear();
        m_exp.clear();
        m_vars.clear();
        m_lexem = leks;

        if (!CheckDec())
            return false;

        if (!CheckSyntax())
            return false;

        leks = m_lexem;
        return true;
    }
    int temp_line = 0;
    bool CheckSyntax()
    {
        for (; pos < m_lexem.size(); pos++)
        {
            /*if(temp_line != m_lexem[pos].m_line)
            {
                temp_line = m_lexem[pos].m_line;
                cout << "I am in line " << m_lexem[pos].m_line << endl;
            }*/
            //cout << m_lexem[pos].m_leks << " I am here" << endl;
            if (m_lexem[pos].m_leks == "<<<")
            {
                gramm.push_back("<<<");
                gramm.push_back("comm");
                gramm.push_back(">>>");
                PrintGramm();
                CompressComm();
                m_lexem.erase(m_lexem.begin() + pos, m_lexem.begin() + pos + 1);
                if (check_op)
                    return true;
            }
            if (m_lexem[pos].m_leks == ";")
            {
                gramm.push_back(";");
                PrintGramm();
                CompressTwoCollun();
                if (check_op)
                    return true;

                continue;
            }
            if (m_lexem[pos].m_type == "Var")
            {
                if (!CheckLet())
                    return false;
                if (check_op)
                    return true;
                continue;
            }
            if (m_lexem[pos].m_leks == "while")
            {
                if (!CheckWhile())
                    return false;
                if (check_op)
                    return true;
                pos++;
                continue;
            }
            if (m_lexem[pos].m_leks == "od")
            {
                if (while_ch)
                    return true;
                else
                    return false;
            }
            if (m_lexem[pos].m_leks == "else")
            {
                if (if_ch)
                    return true;
                else
                    return false;
            }
            if (m_lexem[pos].m_leks == "fi")
            {
                if (if_ch)
                    return true;
                else
                    return false;
            }
            if (m_lexem[pos].m_leks == "case")
            {
                if (select_ch)
                    return true;
                else
                    return false;
            }
            if (m_lexem[pos].m_leks == "otherwise")
            {
                if (select_ch)
                    return true;
                else
                    return false;
            }
            if (m_lexem[pos].m_leks == "ni")
            {
                if (select_ch)
                    return true;
                else
                    return false;
            }
            if (m_lexem[pos].m_leks == "for")
            {
                if (!CheckFor())
                    return false;
                if (check_op)
                    return true;
                pos++;
                continue;
            }
            if (m_lexem[pos].m_leks == "if")
            {
                if (!CheckIf())
                    return false;
                if (check_op)
                    return true;
                continue;
            }
            if (m_lexem[pos].m_leks == "input")
            {
                if (!CheckLoad())
                    return false;
                if (check_op)
                    return true;
                continue;
            }
            if (m_lexem[pos].m_leks == "print")
            {
                if (!CheckPut())
                    return false;
                if (check_op)
                    return true;
                continue;
            }
            if (m_lexem[pos].m_type == "Label")
            {
                gramm.push_back(":L");
                PrintGramm();
                gramm.back() = "op";
                string mark;
                for (auto i : m_lexem[pos].m_leks)
                    if (i != ':')
                        mark.push_back(i);
                if (CheckMark(mark))
                {
                    cout << "Error on line " << m_lexem[pos].m_line;
                    return false;
                }
                m_marks.push_back(mark);
                continue;
            }
            if (m_lexem[pos].m_leks == "jump")
            {
                if (!CheckJump())
                    return false;
                if (check_op)
                    return true;
                continue;
            }
            if (m_lexem[pos].m_leks == "select")
            {
                if (!CheckSwitch())
                    return false;
                if (check_op)
                    return true;
                continue;
            }
            if (m_lexem[pos].m_leks == "throw")
            {
                pos++;
                if (m_lexem[pos].m_leks != ";")
                {
                    cout << "Error in line " << m_lexem[pos].m_line;
                    return false;
                }
                if (check_op)
                    return true;
                continue;
            }
            if (check_op)
                return false;
            if (m_lexem[pos].m_leks == "EOL")
                break;
            cout << "Error in line " << m_lexem[pos].m_line;
            return false;
        }
        if (synt_depth != 0)
        {
            cout << "Error in line " << m_lexem[pos - 2].m_line;
            return false;
        }
        PrintGramm();
        Compress();
        m_lexem.pop_back();
        /*for (auto i : m_lexem)
            cout << i.m_leks << " ";
        cout << endl;*/
        
        return true;
    }
public:
    vector<Lexem_Token> m_lexem;
    vector<vector<string>> m_exp;
private:
    bool IsKey(Lexem_Token lex)
    {
        if (lex.m_type != "Var" && lex.m_type != "Constant" && lex.m_type != "BNConstant" &&
            lex.m_type != "AR_OP" && lex.m_type != "BigNumberOp" &&
            lex.m_type != "Left_Br" && lex.m_type != "Right_Br" && lex.m_type != "temp")
            return true;

        return false;

    }

    bool CheckWhile()
    {
        gramm.push_back("while");
        pos++;
        int temp_exp_type = 0;
        exp_type = 0;
        if (!GetExp(m_get_exp))
        {
            cout << "Error in line " << m_lexem[pos].m_line;
            return false;
        }
        temp_exp_type = exp_type;
        m_lexem.at(pos - 1) = Lexem_Token(m_lexem[pos - 1].m_line, to_string(g_exp_count), "temp");
        m_exp.push_back(m_temp_exp.back());
        m_temp_exp.clear();
        exp_count = 0;
        brac = 0;
        gramm.push_back("E");
        if (m_lexem[pos].m_type == "Order")
        {
            string op = m_lexem[pos].m_leks;
            gramm.push_back("R");
            pos++;
            exp_type = 0;
            if (!GetExp(m_get_exp))
            {
                cout << "Error in line " << m_lexem[pos].m_line;
                return false;
            }
            if (temp_exp_type != exp_type)
            {
                cout << "Error in line " << m_lexem[pos].m_line;
                return false;
            }
            m_lexem.at(pos - 1) = Lexem_Token(m_lexem[pos - 1].m_line, to_string(g_exp_count), "temp");
            g_exp_count++;
            for (auto i : m_temp_exp.back())
                m_exp.back().push_back(i);
            m_exp.back().push_back(op);
            m_temp_exp.clear();
            exp_count = 0;
            brac = 0;
            gramm.push_back("E");
            PrintGramm();
            CompressTest();
        }
        else
        {
            cout << "Error in line " << m_lexem[pos].m_line;
            return false;
        }
        m_lexem.erase(m_lexem.begin() + pos - 2, m_lexem.begin() + pos);
        pos -= 2;
        if (m_lexem[pos].m_leks != "do")
        {
            cout << "Error in line " << m_lexem[pos].m_line << endl;
            return false;
        }
        gramm.push_back("do");
        pos++;
        while_ch++;
        if (!CheckSyntax())
            return false;
        while_ch--;
        PrintGramm();
        Compress();
        gramm.push_back("od");
        gramm.push_back(";");
        PrintGramm();
        CompressWhile();
        return true;
    }

    bool CheckFor()
    {
        gramm.push_back("for");
        int temp_exp_type = 0;
        pos++;
        if (m_lexem[pos].m_type != "Var" && !CheckVar(m_lexem[pos].m_leks))
        {
            cout << "Error in line " << m_lexem[pos].m_line;
            return false;
        }
        gramm.push_back("V");
        for (auto i:m_vars)
            if (i.first == m_lexem[pos].m_leks)
            {
                temp_exp_type = i.second;
            }
        pos++;
        if (m_lexem[pos].m_leks != "from")
        {
            cout << "Error in line " << m_lexem[pos].m_line;
            return false;
        }
        gramm.push_back("from");
        pos++;
        exp_type = temp_exp_type;
        if (!GetExp(m_get_exp))
        {
            cout << "Error in line " << m_lexem[pos].m_line;
            return false;
        }
        gramm.push_back("E");
        m_lexem.at(pos - 1) = Lexem_Token(m_lexem[pos - 1].m_line, to_string(g_exp_count), "temp");
        m_exp.push_back(m_temp_exp.back());
        m_temp_exp.clear();
        g_exp_count++;
        exp_count = 0;
        brac = 0;
        if (m_lexem[pos].m_leks != "to")
        {
            cout << "Error in line " << m_lexem[pos].m_line;
            return false;
        }
        gramm.push_back("to");
        pos++;
        exp_type = temp_exp_type;
        if (!GetExp(m_get_exp))
        {
            cout << "Error in line " << m_lexem[pos].m_line;
            return false;
        }
        gramm.push_back("E");
        m_lexem.at(pos - 1) = Lexem_Token(m_lexem[pos - 1].m_line, to_string(g_exp_count), "temp");
        m_exp.push_back(m_temp_exp.back());
        m_temp_exp.clear();
        g_exp_count++;
        exp_count = 0;
        brac = 0;
        if (m_lexem[pos].m_leks == "by")
        {
            gramm.push_back("by");
            pos++;
            exp_type = temp_exp_type;
            if (!GetExp(m_get_exp))
            {
                cout << "Error in line " << m_lexem[pos].m_line;
                return false;
            }
            gramm.push_back("E");
            m_lexem.at(pos - 1) = Lexem_Token(m_lexem[pos - 1].m_line, to_string(g_exp_count), "temp");
            m_exp.push_back(m_temp_exp.back());
            m_temp_exp.clear();
            g_exp_count++;
            exp_count = 0;
            brac = 0;
        }
        if (m_lexem[pos].m_leks != "do")
        {
            cout << "Error in line " << m_lexem[pos].m_line;
            return false;
        }
        gramm.push_back("do");
        pos++;
        while_ch++;
        if (!CheckSyntax())
        {
            cout << "Expected operator in line " << m_lexem[pos].m_line << endl;
            return false;
        }
        while_ch--;
        PrintGramm();
        Compress();
        gramm.push_back("od");
        gramm.push_back(";");
        PrintGramm();
        CompressFor();
        return true;
    }

    bool CheckIf()
    {
        gramm.push_back("if");
        pos++;
        if (m_lexem[pos].m_leks != "(")
        {
            cout << "Error in line " << m_lexem[pos].m_line << endl;
            return false;
        }
        gramm.push_back("(");
        pos++;
        int temp_exp_type;
        exp_type = 0;
        if (!GetExp(m_get_exp))
        {
            cout << "Error in line " << m_lexem[pos].m_line << endl;
            return false;
        }
        gramm.push_back("E");
        temp_exp_type = exp_type;
        m_lexem.at(pos - 1) = Lexem_Token(m_lexem[pos - 1].m_line, to_string(g_exp_count), "temp");
        m_exp.push_back(m_temp_exp.back());
        m_temp_exp.clear();
        exp_count = 0;
        brac = 0;
        if (m_lexem[pos].m_type == "Order")
        {
            string op = m_lexem[pos].m_leks;
            gramm.push_back("R");
            pos++;
            exp_type = 0;
            if_brac = true;
            if (!GetExp(m_get_exp))
            {
                cout << "Error in line " << m_lexem[pos].m_line << endl;
                return false;
            }
            if (temp_exp_type != exp_type)
            {
                cout << "Error in line " << m_lexem[pos].m_line << endl;
                return false;
            }
            gramm.push_back("E");
            m_lexem.at(pos - 1) = Lexem_Token(m_lexem[pos - 1].m_line, to_string(g_exp_count), "temp");
            g_exp_count++;
            for (auto i : m_temp_exp.back())
                m_exp.back().push_back(i);
            m_exp.back().push_back(op);
            m_temp_exp.clear();
            exp_count = 0;
            brac = 0;
            PrintGramm();
            CompressTest();
            if (m_lexem[pos].m_leks != ")")
            {
                cout << "Error in line " << m_lexem[pos].m_line << endl;
                return false;
            }
            if_brac = false;
            gramm.push_back(")");
        }
        else
        {
            cout << "Error in line " << m_lexem[pos].m_line << endl;
            return false;
        }
        m_lexem.erase(m_lexem.begin() + pos - 2, m_lexem.begin() + pos);
        pos -= 1;
        if_ch++;
        if (!CheckSyntax())
            return false;
        if_ch--;
        PrintGramm();
        Compress();
        if (m_lexem[pos].m_leks == "else")
        {
            gramm.push_back("else");
            pos++;
            if_ch++;
            if (!CheckSyntax())
                return false;
            if_ch--;
            PrintGramm();
            Compress();
        }
        if (m_lexem[pos].m_leks != "fi")
        {
            cout << "Error in line " << m_lexem[pos].m_line << endl;
            return false;
        }
        gramm.push_back("fi");
        pos++;
        if (m_lexem[pos].m_leks != ";")
        {
            cout << "Error in line " << m_lexem[pos].m_line << endl;
            return false;
        }
        gramm.push_back(";");
        PrintGramm();
        CompressIf();
        return true;
    }

    bool CheckSwitch()
    {
        gramm.push_back("select");
        pos++;
        int temp_exp_type;
        exp_type = 0;
        if (!GetExp(m_get_exp))
        {
            cout << "Error in line " << m_lexem[pos].m_line;
            return false;
        }
        gramm.push_back("E");
        temp_exp_type = exp_type;
        m_lexem.at(pos - 1) = Lexem_Token(m_lexem[pos - 1].m_line, to_string(g_exp_count), "temp");
        m_exp.push_back(m_temp_exp.back());
        m_temp_exp.clear();
        g_exp_count++;
        exp_count = 0;
        brac = 0;
        if (m_lexem[pos].m_leks != "in")
        {
            cout << "Error in line " << m_lexem[pos].m_line << endl;
            return false;
        }
        gramm.push_back("in");
        pos++;
        if (m_lexem[pos].m_leks != "case")
        {
            cout << "Error in line " << m_lexem[pos].m_line << endl;
            return false;
        }
        gramm.push_back("case");
        pos++;
        if (m_lexem[pos].m_type == "Constant" && temp_exp_type != 1)
        {
            cout << "Error in line " << m_lexem[pos].m_line;
            return false;
        }
        else if (m_lexem[pos].m_type == "BNConstant" && temp_exp_type != 2)
        {
            cout << "Error in line " << m_lexem[pos].m_line;
            return false;
        }
        else if (m_lexem[pos].m_type == "Constant" && m_lexem[pos].m_type == "BNConstant")
        {
            cout << "Error in line " << m_lexem[pos].m_line;
            return false;
        }
        gramm.push_back("C");
        pos++;
        if (m_lexem[pos].m_leks != ":")
        {
            cout << "Error in line " << m_lexem[pos].m_line;
            return false;
        }
        gramm.push_back(":");
        pos++;
        select_ch++;
        if (!CheckSyntax())
            return false;
        select_ch--;
        PrintGramm();
        Compress();
        while (true)
        {
            if (m_lexem[pos].m_leks == "ni")
                break;
            if (m_lexem[pos].m_leks == "otherwise")
            {
                gramm.push_back("otherwise");
                pos++;
                select_ch++;
                if (!CheckSyntax())
                    return false;
                select_ch--;
                PrintGramm();
                Compress();
                break;
            }
            if (m_lexem[pos].m_leks != "case")
            {
                cout << "Error in line " << m_lexem[pos].m_line << endl;
                return false;
            }
            gramm.push_back("case");
            pos++;
            if (m_lexem[pos].m_type == "Constant" && temp_exp_type != 1)
            {
                cout << "Error in line " << m_lexem[pos].m_line;
                return false;
            }
            else if (m_lexem[pos].m_type == "BNConstant" && temp_exp_type != 2)
            {
                cout << "Error in line " << m_lexem[pos].m_line;
                return false;
            }
            else if (m_lexem[pos].m_type == "Constant" && m_lexem[pos].m_type == "BNConstant")
            {
                cout << "Error in line " << m_lexem[pos].m_line;
                return false;
            }
            gramm.push_back("C");
            pos++;
            if (m_lexem[pos].m_leks != ":")
            {
                cout << "Error in line " << m_lexem[pos].m_line;
                return false;
            }
            gramm.push_back(":");
            pos++;
            select_ch++;
            if (!CheckSyntax())
                return false;
            select_ch--;
            PrintGramm();
            Compress();
        }
        if (m_lexem[pos].m_leks != "ni")
        {
            cout << "Error in line " << m_lexem[pos].m_line;
            return false;
        }
        gramm.push_back("ni");
        pos++;
        if (m_lexem[pos].m_leks != ";")
        {
            cout << "Error in line " << m_lexem[pos].m_line;
            return false;
        }
        gramm.push_back(";");
        PrintGramm();
        CompressSwitch();
        return true;
    }

    bool CheckLoad()
    {
        gramm.push_back("input");
        pos++;
        if (m_lexem[pos].m_type != "var" && !CheckVar(m_lexem[pos].m_leks))
        {
            cout << "Error in line " << m_lexem[pos].m_line;
            return false;
        }
        gramm.push_back("V");
        pos++;
        if (m_lexem[pos].m_leks != ";")
        {
            cout << "Error in line " << m_lexem[pos].m_line;
            return false;
        }
        gramm.push_back(";");
        PrintGramm();
        CompressLoad();
        return true;
    }

    bool CheckPut()
    {
        gramm.push_back("print");
        pos++;
        exp_type = 0;
        if (!GetExp(m_get_exp))
        {
            cout << "Error in line " << m_lexem[pos].m_line << endl;
            return false;
        }
        m_lexem.at(pos - 1) = Lexem_Token(m_lexem[pos - 1].m_line, to_string(g_exp_count), "temp");
        m_exp.push_back(m_temp_exp.back());
        m_temp_exp.clear();
        g_exp_count++;
        exp_count = 0;
        brac = 0;
        gramm.push_back("E");
        if (m_lexem[pos].m_leks != ";")
        {
            cout << "Error in line " << m_lexem[pos].m_line;
            return false;
        }
        gramm.push_back(";");
        PrintGramm();
        CompressPut();
        return true;
    }

    bool CheckLet()
    {
        int temp_exp_type = 0;
        //cout << "I am Here" << endl;
        if(!CheckVar(m_lexem[pos].m_leks))
        {
            cout << "Error in line " << m_lexem[pos].m_line << endl;
            return false;
        }
        for (auto i : m_vars)
            if (i.first == m_lexem[pos].m_leks)
                temp_exp_type = i.second;
        if (pos + 3 >= m_lexem.size())
        {
            cout << "Error in line " << m_lexem[pos].m_line << endl;
            return false;
        }
        gramm.push_back("V");
        pos++;
        if (m_lexem[pos].m_leks != "=")
        {
            cout << "Error in line " << m_lexem[pos].m_line << endl;
            return false;
        }
        gramm.push_back("=");
        pos++;
        exp_type = temp_exp_type;
        if (!GetExp(m_get_exp))
        {
            cout << "Error in line " << m_lexem[pos].m_line << endl;
            return false;
        }
        gramm.push_back("E");
        if (exp_type != temp_exp_type)
        {
            cout << "Error in line " << m_lexem[pos].m_line;
            return false;
        }
        m_lexem.at(pos - 1) = Lexem_Token(m_lexem[pos - 1].m_line, to_string(g_exp_count), "temp");
        g_exp_count++;
        m_exp.push_back(m_temp_exp.back());
        m_temp_exp.clear();
        exp_count = 0;
        brac = 0;
        if (m_lexem[pos].m_leks != ";")
        {
            cout << "Error in line " << m_lexem[pos].m_line;
            return false;
        }
        gramm.push_back(";");
        PrintGramm();
        CompressLet();
        return true;
    }

    bool CheckDec()
    {
        for (; pos < m_lexem.size(); pos++)
        {
        //    cout << m_lexem[pos].m_leks << "  - Here" << endl;
            if (m_lexem[pos].m_type == "Var")
            {
                gramm.push_back("V");
                if (CheckVar(m_lexem[pos].m_leks))
                {
                    cout << "Error in line " << m_lexem[pos].m_line;
                    return false;
                }
                if (pos + 3 < m_lexem.size() && m_lexem[pos + 2].m_type == "Type" && m_lexem[pos + 1].m_leks == ":")
                {
                    gramm.push_back(":");
                    gramm.push_back("Type");
                    m_vars.push_back(pair<string, int>(m_lexem[pos].m_leks, (m_lexem[pos + 2].m_leks == "int" ? 1 : 2)));
                    if (m_lexem[pos + 3].m_leks == ";")
                        pos += 3;
                    else
                    {
                        cout << "Error in line " << m_lexem[pos + 3].m_line << endl;
                        return false;
                    }
                    gramm.push_back(";");
                    PrintGramm();
                    CompressDec();
                }
                else
                {
                    cout << "Error in line " << m_lexem[pos].m_line << endl;
                    return false;
                }
            }
            else
                break;
            if (m_lexem[pos + 2].m_leks != ":")
                break;
        }
        PrintGramm();
        Compress();
        return true;
    }

    bool GetExp(vector<string>& exp)
    {
        
        depth++;
        int start = pos;
        int end = pos;
        bool brac_ch = brac;
        // ���������, ��� ��������� ����� ���� ���������� � �������� ��� �������
        for (; pos < m_lexem.size(); pos++)
        {
            if (m_lexem[pos].m_type == "Var")
            {
                
                free_exp = false;
                for (auto i : m_vars)
                    if (i.first == m_lexem[pos].m_leks)
                    {
                        if (exp_type == 0)
                            exp_type = i.second;
                        else if (exp_type != i.second)
                            return false;
                    }
            }
            if (m_lexem[pos].m_type == "Constant")
            {
                free_exp = false;
                if (exp_type == 0)
                {
                    exp_type = 1;
                }
                else
                {
                    if (exp_type == 2)
                        return false;
                }
            }
            if (m_lexem[pos].m_type == "BNConstant")
            {
                
                free_exp = false;
                if (exp_type == 0)
                {
                    exp_type = 2;
                }
                else
                {
                    if (exp_type == 1)
                        return false;
                }
            }
            if (m_lexem[pos].m_leks == "(")
            {
                free_exp = false;
                brac++;
                pos++;
                //cout << "New depth   " << m_lexem[pos].m_leks << endl;
                if (!GetExp(exp))
                    return false;
                pos++;
            }
            if (m_lexem[pos].m_leks == ")" && brac == 0)
            {
                if (if_brac)
                {
                    break;
                }
                if (put_depth)
                    break;
                else
                    return false;
            }
            else if (m_lexem[pos].m_leks == ")")
            {

                brac--;
                brac_ch = false;
                break;
            }
            if (m_lexem[pos].m_type == "BigNumberOp")
            {
                if (exp_type == 0)
                    exp_type = 2;
                else if (exp_type != 2)
                {
                    
                    return false;
                }
                if (!free_exp)
                {
                    return false;
                }
                if (!GetBN(pos))
                    return false;

                break;
            }
            if (IsKey(m_lexem[pos]))
                break;
        }
        /*for (auto i : m_lexem)
            cout << i.m_leks << " ";
        cout << endl << endl << "____________________________" << endl << endl;*/
        end = pos;
        if (brac_ch && !hash_read)
        {
            cout << "Errors in bracet placing" << endl;
            return false;
        }
        if (start == end)
        {
            cout << "Expression is missing" << endl;
            return false;
        }
        // ���������� ��������� � �������
        for (int i = start; i < end; i++)
        {
            if (m_lexem[i].m_leks == "*" || m_lexem[i].m_leks == "/" || m_lexem[i].m_leks == "%")
            {
                if (i - 1 >= start && i + 1 < end)
                {
                    if (m_lexem[i - 1].m_type == "BNConstant" || m_lexem[i - 1].m_type == "Constant" || (m_lexem[i - 1].m_type == "Var" && CheckVar(m_lexem[i - 1].m_leks)))
                        exp.push_back(m_lexem[i - 1].m_leks);
                    else if (m_lexem[i - 1].m_type == "temp")
                        for (auto i : m_temp_exp[atoi(m_lexem[i - 1].m_leks.c_str())])
                            exp.push_back(i);
                    else
                    {
                        cout << "First arg " << m_lexem[i].m_leks << " is invalid at line" << m_lexem[i].m_line << endl;
                        return false;
                    }

                    if (m_lexem[i + 1].m_type == "BNConstant" || m_lexem[i + 1].m_type == "Constant" || (m_lexem[i + 1].m_type == "Var" && CheckVar(m_lexem[i + 1].m_leks)))
                        exp.push_back(m_lexem[i + 1].m_leks);
                    else if (m_lexem[i + 1].m_type == "temp")
                        for (auto i : m_temp_exp[atoi(m_lexem[i + 1].m_leks.c_str())])
                            exp.push_back(i);
                    else
                    {
                        cout << "Sec arg " << m_lexem[i].m_leks << " is invalid at line" << m_lexem[i].m_line << endl;
                        return false;
                    }

                    exp.push_back(m_lexem[i].m_leks);
                    m_lexem.at(i - 1) = Lexem_Token(m_lexem[i - 1].m_line, to_string(exp_count), "temp");
                    m_temp_exp.push_back(exp);
                    exp.clear();
                    exp_count++;
                    m_lexem.erase(m_lexem.begin() + i, m_lexem.begin() + i + 2);
                    end = end - 2;
                    i = start;
                }
            }
        }

        //����������� �������� � ���������
        for (int i = start; i < end; i++)
        {
            if (m_lexem[i].m_leks == "+" || m_lexem[i].m_leks == "-")
            {
                if (i - 1 >= start && i + 1 < end)
                {
                    //cout << m_lexem[i - 1].m_leks << " lasjdifjlas " << m_lexem[i + 1].m_leks << endl;
                    if (m_lexem[i - 1].m_type == "BNConstant" || m_lexem[i - 1].m_type == "Constant" || (m_lexem[i - 1].m_type == "Var" && CheckVar(m_lexem[i - 1].m_leks)))
                        exp.push_back(m_lexem[i - 1].m_leks);
                    else if (m_lexem[i - 1].m_type == "temp")
                    {
                        for (auto i : m_temp_exp[atoi(m_lexem[i - 1].m_leks.c_str())])
                            exp.push_back(i);
                    }
                    else
                    {
                        cout << "First arg " << m_lexem[i].m_leks << " is invalid at line" << m_lexem[i].m_line << endl;
                        return false;
                    }

                    if (m_lexem[i + 1].m_type == "BNConstant" || m_lexem[i + 1].m_type == "Constant" || (m_lexem[i + 1].m_type == "Var" && CheckVar(m_lexem[i + 1].m_leks)))
                        exp.push_back(m_lexem[i + 1].m_leks);
                    else if (m_lexem[i + 1].m_type == "temp")
                    {
                        for (auto i : m_temp_exp[atoi(m_lexem[i + 1].m_leks.c_str())])
                            exp.push_back(i);
                    }
                    else
                    {
                        cout << "Sec arg " << m_lexem[i].m_leks << " is invalid at line" << m_lexem[i].m_line << endl;
                        return false;
                    }

                    exp.push_back(m_lexem[i].m_leks);
                    m_lexem.at(i - 1) = Lexem_Token(m_lexem[i - 1].m_line, to_string(exp_count), "temp");
                    m_temp_exp.push_back(exp);
                    exp.clear();
                    exp_count++;
                    m_lexem.erase(m_lexem.begin() + i, m_lexem.begin() + i + 2);
                    end = end - 2;
                    i = start;
                }
            }
        }
        /*for (auto i : m_lexem)
            cout << i.m_leks << " ";
        cout << endl;*/
        //cout << m_lexem[start - 1].m_leks << " " << m_lexem[start].m_type << " " << m_lexem[end].m_leks << endl;
        if (start + 1 == end)
        {
            if (m_lexem[start].m_type == "temp")
                m_lexem.at((depth == 1 || (depth == hash_depth && hash_read) ? start : start - 1)) = m_lexem[start];
            else if (m_lexem[start].m_type == "BNConstant" || m_lexem[start].m_type == "Constant" || (m_lexem[start].m_type == "Var" && CheckVar(m_lexem[start].m_leks)))
            {
                exp.push_back(m_lexem[start].m_leks);
                m_temp_exp.push_back(exp);
                exp.clear();
                m_lexem.at((depth == 1 || (depth == hash_depth && hash_read) ? start : start - 1)) = Lexem_Token(m_lexem[start].m_line, to_string(exp_count), "temp");
                exp_count++;
            }
            else
            {
                //cout << m_lexem[pos].m_leks << endl;
                cout << "Invalid expression" << endl;
                return false;
            }

            m_lexem.erase(m_lexem.begin() + (depth == 1 || (depth == hash_depth && hash_read) ? start + 1 : start), m_lexem.begin() + (depth == 1 || (depth == hash_depth && hash_read) ? end : end + 1));
            end = (depth == 1 || (depth == hash_depth && hash_read) ? end : end - 2);
        }
        else
        {
            cout << "Invalid expression" << endl;
            return false;
        }
        pos = end;
        depth--;
        if (depth == 0)
        {
            free_exp = true;
        }
        return true;
    }

    bool CheckVar(string var)
    {
        for (auto i : m_vars)
            if (i.first == var)
                return true;

        return false;
    }

    bool CheckMark(string mark)
    {
        for (auto i : m_marks)
            if (i == mark)
                return true;

        return false;
    }

    bool CheckJump()
    {
        gramm.push_back("jump");
        pos++;
        string mark = m_lexem[pos].m_leks;
        if (!CheckMark(mark))
        {
            cout << "Error in line " << m_lexem[pos].m_line << endl;
            return false;
        }
        gramm.push_back("L");
        pos++;
        if (m_lexem[pos].m_leks != ";")
        {
            cout << "Error in line " << m_lexem[pos].m_line << endl;
            return false;
        }
        gramm.push_back(";");
        PrintGramm();
        CompressJump();
        return true;
    }

    bool GetBN(int start)
    {
        string op = m_lexem[start].m_leks;
        pos++;
        if (m_lexem[pos].m_leks != "(")
        {
            cout << "Error on line " << m_lexem[pos].m_line;
            return false;
        }
        pos++;
        exp_type = 2;
        if (m_lexem[pos].m_type != "BNConstant" && m_lexem[pos].m_type != "Var")
            return false;
        else if (m_lexem[pos].m_type == "Var")
        {
            for(auto i:m_vars)
                if (i.first == m_lexem[pos].m_leks)
                {
                    if (i.second != 2)
                    {
                        cout << "Error on line " << m_lexem[pos].m_line;
                        return false;
                    }
                }
        }
        pos++;
        if (m_lexem[pos].m_leks == ",")
        {
            pos++;
            if (m_lexem[pos].m_type != "BNConstant" && m_lexem[pos].m_type != "Var")
                return false;
            else if (m_lexem[pos].m_type == "Var")
            {
                for (auto i : m_vars)
                    if (i.first == m_lexem[pos].m_leks)
                    {
                        if (i.second != 2)
                        {
                            cout << "Error on line " << m_lexem[pos].m_line;
                            return false;
                        }
                    }
            }
            pos++;
        }
        if (m_lexem[pos].m_leks != ")")
        {
            cout << "Error on line " << m_lexem[pos].m_line;
            return false;
        }
        vector <string> exp;
        exp.push_back(m_lexem[start + 2].m_leks);
        exp.push_back(m_lexem[start + 4].m_leks);
        exp.push_back(op);
        m_temp_exp.push_back(exp);
        exp.clear();
        m_lexem.at(start) = Lexem_Token(m_lexem.at(start).m_line, to_string(exp_count), "temp");
        exp_count++;
        m_lexem.erase(m_lexem.begin() + start + 1, m_lexem.begin() + pos + 1);
        pos = start + 1;
        return true;
    }

    void CompressDec()
    {
        gramm.erase(gramm.end() - 4, gramm.end());
        gramm.push_back("dec");
    }

    void PrintGramm()
    {
        /*for (auto i : gramm)
            cout << i << " ";
        cout << endl;*/
    }

    void CompressTwoCollun()
    {
        gramm.back() = "op";
    }

    void CompressComm()
    {
        gramm.pop_back();
        gramm.pop_back();
        gramm.back() = "op";
    }

    void CompressLet()
    {
        if (*(gramm.end() - 2) == "E")
            *(gramm.end() - 2) = "T";
        gramm.erase(gramm.end() - 4, gramm.end());
        gramm.push_back("op");
        /*for (auto i : gramm)
            cout << i << " ";
        cout << endl;*/
    }

    void CompressWhile()
    {
        gramm.erase(gramm.end() - 6, gramm.end());
        gramm.push_back("op");
    }

    void CompressFor()
    {
        bool by = false;
        for (auto i : gramm)
            if (i == "by")
                by = true;
        gramm.erase(gramm.end() - (by ? 12 : 10), gramm.end());
        gramm.push_back("op");
    }

    void CompressIf()
    {
        bool _else = false;
        for (auto i : gramm)
            if (i == "else")
                _else = true;
        gramm.erase(gramm.end() - (_else ? 9 : 7), gramm.end());
        gramm.push_back("op");
    }

    void CompressSwitch()
    {
        if (*(gramm.end() - 4) == "otherwise")
        {
            *(gramm.end() - 4) = "cases";
            gramm.erase(gramm.end() - 3);
        }
        while (true)
        {
            if (*(gramm.end() - 6) == "select")
            {
                break;
            }
            if (*(gramm.end() - 7) == "case")
            {
                *(gramm.end() - 7) = "cases";
                gramm.erase(gramm.end() - 6, gramm.end() - 2);
            }
            if (*(gramm.end() - 6) == "case")
            {
                *(gramm.end() - 6) = "cases";
                gramm.erase(gramm.end() - 5, gramm.end() - 2);
            }
        }
        gramm.erase(gramm.end() - 6, gramm.end());
        gramm.push_back("op");
    }

    void CompressPut()
    {
        gramm.erase(gramm.end() - 3, gramm.end());
        gramm.push_back("op");
    }

    void CompressLoad()
    {
        gramm.erase(gramm.end() - 3, gramm.end());
        gramm.push_back("op");
    }

    void CompressJump()
    {
        gramm.erase(gramm.end() - 3, gramm.end());
        gramm.push_back("op");
    }

    void CompressTest()
    {
        gramm.erase(gramm.end() - 3, gramm.end());
        gramm.push_back("T");
    }

    void Compress()
    {
        if (m_lexem[pos].m_leks == "od" || m_lexem[pos].m_leks == "fi" || m_lexem[pos].m_leks == "ni" 
            || m_lexem[pos].m_leks == "else" || m_lexem[pos].m_leks == "case" || m_lexem[pos].m_leks == "otherwise")
        {
            if (gramm.back() == "op")
            {
                gramm.back() = "P";
                PrintGramm();
                while (*(gramm.end() - 2) == "op")
                {
                    *(gramm.end() - 2) = "P";
                    gramm.pop_back();
                    PrintGramm();
                }
            }
            else
            {
                gramm.push_back("P");
            }
        }
        if (m_lexem[pos].m_leks == "EOL")
        {
            if (gramm.back() == "op")
                gramm.back() = "P";
            PrintGramm();
            while (*(gramm.end() - 2) == "op")
            {
                *(gramm.end() - 2) = "P";
                gramm.pop_back();
                PrintGramm();
            }
        }
        if (gramm.back() == "P" && *(gramm.end() - 2) == "D")
        {
            *(gramm.end() - 2) = "S";
            gramm.pop_back();
            PrintGramm();
        }
        if (gramm.back() == "dec")
        {
            gramm.back() = "D";
            PrintGramm();
            while (gramm.size() > 1)
            {
                *(gramm.end() - 2) = "D";
                gramm.pop_back();
                PrintGramm();
            }
        }
    }
private:
    // �����
    int exp_type = 0;
    int pos = 0;
    int check_op = 0;
    int put_depth = 0;
    int synt_depth = 0;
    int while_ch = 0;
    int if_ch = 0;
    int select_ch = 0;
    bool if_brac = false;
    int exp_count = 0;
    int depth = 0;
    int brac = 0;
    int hash_depth = 0;
    int hash_read = 0;
    int hash_brac = 0;
    int g_exp_count = 0;
    bool free_exp = true;
    vector<string> m_get_exp;
    vector<string> m_marks;
    vector<vector<string>> m_temp_exp;
    vector<pair<string, int>> m_vars;
    vector<string> gramm;
};