#pragma once
#include "Lexer.h"
#include "Translator.h"
#include "Syntaxer.h"
#include "Oracle.h"
#include "OracleBuilder.h"

bool Translate(string filename);