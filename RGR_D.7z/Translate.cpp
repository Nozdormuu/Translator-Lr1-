#include "Translate.h"

bool Translate(string filename)
{
	vector <Lexem_Token> leks;
	leks = Lexer(filename);
	Syntaxer synt;
	if (synt.Start(leks))
	{
		cout << "Accepted" << endl;
		Translator trans;
		trans.Start(leks, synt.m_exp, "out.txt");
		return true;
	}
	return false;
}
