////����� ����� Sloz, Get, Blop, Nr, Mns, Umn, Obr, Tr, Mnr  

//get - ������ � ��������
//obr - ���������
//blop - �������� ��������� (==)
//nr - �������� ��������� (!=)
//tr - ����������������
//mnr - ��������� ����������
//sloz - ��������
//mns - ���������
//umn - ���������

#include <iostream>
#include <fstream>
#include<algorithm>
#include <string>
#include <Windows.h>
#include<sstream>
#include <vector>
#include <stack>
#include <list>
using namespace std;
class Iterator;

int stlen(const char* str) {
	int i = 0;
	while (str[i] != '\0')
		i++;
	return i;
}

bool isd(char is) {
	char arr[10] = { '0','1','2','3','4','5','6','7','8','9' };
	for (int i = 0; arr[i] != '\0'; i++)
		if (is == arr[i])
			return true;
	return false;

}
int dlina(long long int x) {
	int i = 0;
	while (x) {
		i++;
		x /= 10;
	}
	return i;
}
int m_max(int x, int y) {
	return (x > y ? x : y);
}


class BigNumber
{
public:
	char* arr;
	size_t size = 0;
	bool neg = false;

	friend std::ostream& operator<<(std::ostream& os, const BigNumber& num);
	friend std::istream& operator>>(std::istream& is, BigNumber& num);
	friend BigNumber operator+(BigNumber& num1, BigNumber& num2);
	friend BigNumber operator-(BigNumber& num1, BigNumber& num2);
	friend BigNumber operator%(const BigNumber& num1, const BigNumber& num2);
	friend BigNumber operator/(const BigNumber& num1, const BigNumber& num2);
	friend BigNumber operator*(BigNumber& num1, BigNumber& num2);

	bool operator>(const BigNumber& num)const {
		if (size > num.size)
			return true;
		if (size < num.size)
			return false;
		for (int i = 0; i < size; i++)
		{
			if ((arr[i]) > (num.arr[i])) {
				return true;
			}
			if ((arr[i]) < (num.arr[i])) {
				return false;
			}
		}
		if (arr[size - 1] == num.arr[size - 1]) {
			return false;
		}
		return true;
	}
	bool operator>=(const BigNumber& num)const { return (!(*this < num)); }
	bool operator<=(const BigNumber& num)const { return (!(*this > num)); }
	bool operator<(const BigNumber& num)const
	{
		return num > *this;
	}
	bool operator==(const BigNumber& num) const
	{
		if ((size != num.size))
			return false;
		for (int i = 0; i < size; i++) {
			if (arr[i] != num.arr[i])
				return false;
		}
		return true;
	}
	bool operator!=(const BigNumber& num) const
	{
		return!(*this == num);
	}
	bool operator!() {
		return (arr == nullptr);
	}
	char& operator[](size_t index) { return arr[index]; }
	const char& operator[](size_t index)const { return arr[index]; }
	char Get_digit(int pos)
	{
		if (isd(arr[pos]))
			return arr[pos];
	};

	BigNumber& Get_digit(BigNumber& num) {
		string ans = "";
		BigNumber answer;
		int i = 0;
		while (true) {
			ans = to_string(i);
			BigNumber bn(ans);
			if (i < this->size)
				if (bn == num)
				{
					ans = this->Get_digit(i);
					BigNumber a(ans);
					answer = a;
					break;
				}
			if (i == this->size) {
				ans = "0";
				BigNumber a(ans);
				answer = a;
				break;
			}
			i++;
		}

		return answer;
	}

	void Set_digit(int pos, char i) {
		if (isd(i) and (isd(arr[pos])))
			arr[pos] = i;
	};

	Iterator begin();
	Iterator end();

	BigNumber()
	{
		size = 1;
		neg = false;
		arr = new char[size];
		arr[0] = '0';
	}

	BigNumber(const BigNumber& num)
	{
		arr = new char[num.size];
		for (int i = 0; i < num.size; i++)
			arr[i] = num.arr[i];
		size = num.size;
		neg = num.neg;

	}
	BigNumber(const char* str)
	{
		if (str[0] == '-')
			neg = 1;

		size = stlen(str);
		arr = new char[size + 1];
		for (int i = 0; i < size; i++)
			arr[i] = str[i];
		arr[size] = '\0';
	}
	BigNumber(string str)
	{
		if (str[0] == '-')
			neg = 1;

		size = str.size();
		arr = new char[size + 1];
		for (int i = 0; i < size; i++)
			arr[i] = str[i];
		arr[size] = '\0';
	}

	~BigNumber()
	{
		if (arr != nullptr)
			delete[]arr;
		size_t size = 0;

		bool neg = 0;
	}
	BigNumber& operator=(const BigNumber& num)
	{
		if (&num == this)
			return *this;

		if (arr != nullptr)
			delete[] arr;

		int c = num.size;
		neg = num.neg;

		arr = new char[c];
		for (int i = 0; i < c; i++)
			arr[i] = num.arr[i];
		size = c;
		return *this;


	}

	string get_string() {
		string num = "";
		for (int i = 0; i < size; i++)
			num += arr[i];
		if (num == "")
			num = "0";
		return num;
	}

};
std::ostream& operator<<(std::ostream& os, const BigNumber& num)
{
	for (int i = 0; i < num.size; i++)
		os << num.arr[i];
	os << std::endl;
	return os;
}
std::istream& operator>>(std::istream& is, BigNumber& num) {
	char* ptr1 = new char[1024];
	is >> ptr1;
	num = BigNumber(ptr1);
	delete[] ptr1;
	return is;

}


class Iterator
{
	char* ptr;
public:

	char& operator*()
	{
		return *ptr;

	}
	char* operator->() {
		return ptr;
	}
	bool operator==(const Iterator& it)
	{
		return(ptr == it.ptr);

	}
	bool operator!= (const Iterator& it)
	{
		return(ptr != it.ptr);

	}
	Iterator operator++(int)
	{
		Iterator old = *this;
		ptr = ptr + 1;
		return old;
	}
	Iterator& operator++()
	{
		ptr = ptr + 1;
		return*this;

	}
	friend class BigNumber;
};

Iterator BigNumber::begin()
{
	Iterator it;
	it.ptr = &arr[0];
	return it;

}

Iterator BigNumber::end()
{
	Iterator it;
	it.ptr = arr + size;
	return it;

}

void Make_with_eq_lenght(BigNumber& num1, BigNumber& num2)
{
	int c = m_max(num1.size, num2.size) + 1;
	char* num_copy1 = new char[c];
	char* num_copy2 = new char[c];
	for (int i = 0; i < c; i++)
		num_copy1[i] = '0';
	for (int i = 0; i < num1.size; i++)
		num_copy1[c - i - 1] = num1.arr[num1.size - i - 1];
	for (int i = 0; i < c; i++)
		num_copy2[i] = '0';
	for (int i = 0; i < num2.size; i++)
		num_copy2[c - i - 1] = num2.arr[num2.size - i - 1];
	delete[] num1.arr;
	delete num2.arr;
	num1.size = c;
	num2.size = c;
	num1.arr = num_copy1;
	num2.arr = num_copy2;
}

void DeleteNulls(BigNumber& num1) {
	int count = 0;
	int i = 0;
	while (i < num1.size) {
		if (num1.arr[i] == '0')
			count++;
		else { break; }
		i++;
	}

	int c = num1.size - count;
	char* new_arr = new char[c];
	for (int i = 0; i < c; i++)
		new_arr[i] = num1.arr[i + count];
	delete[] num1.arr;
	num1.size = c;
	num1.arr = new_arr;


}

void DeleteStar(BigNumber& num1) {
	int count = 0;
	int i = 0;
	while (i < num1.size) {
		if (num1.arr[i] == '*')
			count++;
		else { break; }
		i++;
	}

	int c = num1.size - count;
	char* new_arr = new char[c];
	for (int i = 0; i < c; i++)
		new_arr[i] = num1.arr[i + count];
	delete[] num1.arr;
	num1.size = c;
	num1.arr = new_arr;


}

BigNumber operator+(BigNumber& num1, BigNumber& num2) {

	BigNumber res;
	res.arr = new char[m_max(num1.size, num2.size) + 1];
	res.size = m_max(num1.size, num2.size) + 1;
	Make_with_eq_lenght(num1, num2);
	int carry = 0;
	for (int i = num1.size - 1; i >= 0; i--) {
		res.arr[i] = ((num1.arr[i] - '0') + (num2.arr[i] - '0') + carry) % 10 + '0';
		carry = int(((num1.arr[i] - '0') + (num2.arr[i] - '0') + carry) / 10);

	}
	DeleteNulls(res);
	DeleteNulls(num1);
	DeleteNulls(num2);
	return res;
}

template<typename T>
inline void SwapMe(T* first, T* second)
{
	if (*first != *second)
	{
		T tmp = *first;
		*first = *second;
		*second = tmp;
	}
}

BigNumber operator-(BigNumber& num1, BigNumber& num2) {// ��������� � ������

	BigNumber res;
	if (num1 < num2) { BigNumber tmp = num1; num1 = num2; num2 = tmp; }


	res.arr = new char[m_max(num1.size, num2.size)];
	res.size = m_max(num1.size, num2.size);
	res = num1;
	int dl = num1.size - num2.size;
	for (int i = 0; i < num2.size; i++) {
		if (res[i + dl] >= num2[i]) {
			res[i + dl] = ((res[i + dl] - '0') - (num2[i] - '0') + '0');
		}
		else {
			for (int j = i + dl; j > 0; j--) {
				if (res[j - 1] == '0')
					res[j - 1] = '9';
				else {
					res[j - 1] = ((res[j - 1] - '0') - 1) + '0';
					res[i + dl] = ((res[i + dl] - '0') - (num2[i] - '0') + 10) + '0';
					break;
				}

			}

		}

	}
	DeleteNulls(res);

	return res;
}

BigNumber mult_dig(BigNumber& num, char ix)
{
	BigNumber res;
	res.arr = new char[num.size + 1];
	res.size = num.size + 1;
	Make_with_eq_lenght(res, num);

	int carry = 0;
	for (int i = num.size - 1; i >= 0; i--) {
		res.arr[i] = ((num.arr[i] - '0') * (ix - '0') + carry) % 10 + '0';
		carry = int(((num.arr[i] - '0') * (ix - '0') + carry) / 10);

	}
	DeleteNulls(res);
	DeleteNulls(num);

	return res;

}

BigNumber sdvig(BigNumber& num, int ix)
{

	char* new_arr = new char[num.size + ix];
	for (int i = 0; i < num.size; i++)
		new_arr[i] = num[i];
	for (int i = num.size; i < num.size + ix; i++)
		new_arr[i] = '0';
	delete[] num.arr;
	num.arr = new_arr;

	num.size = num.size + ix;
	return num;

}

BigNumber operator*(BigNumber& num1, BigNumber& num2)
{
	BigNumber res;
	BigNumber temp;
	if (num1.size < num2.size) { SwapMe(&num1, &num2); }
	char ix;
	for (int i = num2.size; i > 0; i--) {
		ix = num2[i - 1];
		temp = mult_dig(num1, ix);
		temp = sdvig(temp, num2.size - i);
		res = res + temp;
	}
	return res;
}


BigNumber cut(BigNumber& num1, BigNumber& num2)
{
	BigNumber res;
	res.arr = new char[num2.size];
	res.size = num2.size;
	for (int i = 0; i < num2.size; i++) {
		res[i] = num1[i];
		num1[i] = '*';
	}
	DeleteStar(num1);
	return res;
}

BigNumber cutty(BigNumber& num1, BigNumber& num2, int c) {
	BigNumber copy;
	if ((num2.size < c))
	{
		copy.arr = new char[num1.size + num2.size];
		copy.size = num1.size + num2.size;
		for (int i = 0; i < num1.size; i++)
			copy[i] = num1[i];
		for (int i = num1.size; i < copy.size; i++)
		{
			copy[i] = num2[i - num1.size];
			num2[i - num1.size] = '*';
		}
		DeleteStar(num2);
		return copy;

	}
	copy.arr = new char[num1.size + c];
	copy.size = num1.size + c;
	for (int i = 0; i < num1.size; i++)
		copy[i] = num1[i];
	for (int i = num1.size; i < copy.size; i++)
	{
		copy[i] = num2[i - num1.size];
		num2[i - num1.size] = '*';
	}
	DeleteStar(num2);
	num1 = copy;

	return copy;
}

void  del10(BigNumber& num1) {
	BigNumber res;
	res.arr = new char[num1.size - 1];
	res.size = num1.size - 1;
	for (int i = 0; i < res.size; i++)
		res[i] = num1[i];
	num1 = res;

}

void Deletefirst(BigNumber& num)
{

	char* new_arr = new char[num.size - 1];

	for (int i = 1; i < num.size; i++)
		new_arr[i - 1] = num[i];
	num.arr = new_arr;
	num.size = num.size - 1;



}


BigNumber operator/(BigNumber& num1, BigNumber& num2) {
	BigNumber i1("");
	BigNumber i2("0");
	if (num2 == i1) { std::cout << "zero"; throw 0; }
	if (num2 == i2) { std::cout << "zero"; throw 0; }


	if (num1 < num2)
		return BigNumber("");

	BigNumber res("");
	BigNumber ost = num1;
	BigNumber temp = cut(ost, num2);
	BigNumber i("1");

	while (true) {

		while (temp >= num2) {
			temp = temp - num2;
			res = res + i;

		}
		while ((temp) == "" and (ost[0] == '0')) {
			Deletefirst(ost);
			sdvig(res, 1);
		}
		while (temp < num2)
			if (ost != "") {
				cutty(temp, ost, 1);
				sdvig(res, 1);
			}
			else {
				return res;
			}


	}


}

BigNumber operator%(BigNumber& num1, BigNumber& num2) {
	BigNumber i("1");
	BigNumber i1("");
	BigNumber i2("0");
	if (num2 == i1) { std::cout << "zero"; throw 0; }
	if (num2 == i2) { std::cout << "zero"; throw 0; }
	if (num2 == i) { return num1; }
	BigNumber res;

	BigNumber time_num1 = num1;
	BigNumber time_num2 = num2;
	res = time_num1 / time_num2;
	res = res * time_num2;
	res = time_num1 - res;

	return res;
}




