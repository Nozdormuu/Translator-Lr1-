#include "Oracle.h"



Oracle::Oracle()
{
}

Oracle::Oracle(int terminals, int non_terminals, int states) :
   sr_table(states, std::vector<OracleAction>(terminals + 1, { OracleActionType::_error, 0 })),
   goto_table(states, std::vector<OracleAction>(non_terminals, { OracleActionType::_error, 0 }))
{

}

Oracle::~Oracle()
{
}
