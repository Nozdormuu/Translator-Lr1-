﻿// RGR_D.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include "Base.h"
#include "Lexer.h"
#include "OracleBuilder.h"
#include "SyntaxAnalyser.h"
#include "BigNumber.h"
#include <vector>
#include <string>
#include <stack>
#include <sstream>
#pragma warning(disable : 4996)

std::string GetArg(std::string& arg)
{
	return arg;
}

int CharToInt(std::string& str)
{
	int res = 0;

	for (int i = 0; str[i] != '\0'; i++)
		res = res * 10 + (str[i] - '0');

	return res;
}

void Interpret(std::vector<std::string>& keywords, std::vector<std::string>& leksems, int leks)
{
	string tempstr;
	std::stack<std::string> stack;
	std::vector<std::string> vars;
	std::vector<std::string> vals;
	std::stringstream temp;
	int l = 0;
	int i = 1;
	int hellp = 1;
	try
	{
		while (l < leks)
		{
			if (leksems[l] == "throw")
				throw "Exception on line ";
			//std::cout << l << std::endl;
			if (leksems[l] == "push")
			{
				l++;

				if ((leksems[l][0] >= '0' && leksems[l][0] <= '9') || leksems[l][0] == '[')
					stack.push(leksems[l]);
				else if (leksems[l] != "error")
				{
					bool ch = false;

					for (auto i : vars)
						if (i == leksems[l])
							ch = true;

					if (ch)
					{
						int j = 0;
						for (; vars[j] != leksems[l]; j++) { ; }
						stack.push(vals[j]);
					}
					else
						throw "Error: Using unitiliazed variable on line ";
				}
				else
					throw "Error: Invalid argument for 'push' on line ";
			}
			if (leksems[l] == "pop")
			{
				l++;
				bool ch = true;

				for (auto i : keywords)
					if (i == leksems[l])
						ch = false;

				if (leksems[l] != "error" && ch)
				{
					ch = false;

					for (auto i : vars)
						if (i == leksems[l])
							ch = true;

					if (ch)
					{
						ch = true;

						int j = 0;
						for (; vars[j] != leksems[l]; j++) { ; }

						if (vals[j][0] != '[' && stack.top()[0] == '[' && vars[j] != "switch")
							ch = false;
						else if (vals[j][0] == '[' && stack.top()[0] != '[' && vars[j] != "switch")
							ch = false;

						if (ch)
						{
							vals[j] = stack.top();
							stack.pop();
						}
						else
							throw "Error: Wrong type on line ";
					}
					else
					{
						if (stack.top() == "error")
							throw "Error: Invalid argument for operation on line ";
						else
						{
							vars.push_back(leksems[l]);
							vals.push_back(stack.top());
							stack.pop();
						}
					}
				}
				else
					throw "Error: Invalid argument for 'pop' on line ";
			}
			if (leksems[l] == "jmp")
			{
				l++;

				if (leksems[l] != "error")
				{
					int temp = CharToInt(leksems[l]);
					l = 0;
					i = 0;

					if (temp < leks)
					{
						while (i != (temp - 1))
						{
							if (leksems[l] == "\\n")
								i++;

							l++;
						}

						l--;
					}
					else
						throw "Error: Given parameter does not exist for 'jmp' on line ";
				}
				else
					throw "Error: Invalid parameter for 'jmp' on line ";
			}
			if (leksems[l] == "ji")
			{
				l++;

				if (leksems[l][0] >= '0' && leksems[l][0] <= '9')
				{
					if (stack.top()[0] != '0')
					{
						int temp = CharToInt(leksems[l]);
						l = 0;
						i = 0;

						if (temp < leks)
						{
							while (i != (temp - 1))
							{
								if (leksems[l] == "\\n")
									i++;

								l++;
							}

							l--;
						}
						else
							throw "Error: Given parameter does not exist for 'jmp' on line ";
					}

					stack.pop();
				}
				else
					throw "Error: Invalid value at the top of the stack for ji on line ";
			}
			if (leksems[l] == "+" ||
				leksems[l] == "-" ||
				leksems[l] == "*" ||
				leksems[l] == "%" ||
				leksems[l] == "/")
			{
				if (stack.top()[0] == '&')
				{
					std::istringstream in2;
					in2.str(stack.top());
					BigNumber temp2;
					in2 >> temp2;
					stack.pop();

					if (stack.top()[0] != '[')
						throw "Error: Arguments of differing types for operation of line ";

					std::istringstream in1;
					in1.str(stack.top());
					BigNumber temp1;
					in1 >> temp1;
					stack.pop();

					std::string res;
					BigNumber res_;

					switch (leksems[l][0])
					{
					case '+':
						res_ = temp1 + temp2;
						break;
					case '-':
						res_ = temp1 - temp2;
						break;
					case '*':
						res_ = temp1 * temp2;
						break;
					case '%':
						res_ = temp1 % temp2;
						break;
					default:
						res_ = temp1 / temp2;
						break;
					}
					std::ostringstream out;
					out << res_;
					res = out.str();

					stack.push(res);
				}
				else
				{
					int temp2 = CharToInt(stack.top());
					stack.pop();

					if (stack.top()[0] == '[')
						throw "Error: Arguments of differing types for operation of line ";

					int temp1 = CharToInt(stack.top());
					stack.pop();
					int res_ = 0;

					switch (leksems[l][0])
					{
					case '+':
						res_ = temp1 + temp2;
						break;
					case '-':
						res_ = temp1 - temp2;
						break;
					case '*':
						res_ = temp1 * temp2;
						break;
					case '%':
						res_ = temp1 % temp2;
						break;
					default:
						if (temp2 == 0)
							throw "Error: Division by 0 on line ";

						res_ = temp1 / temp2;
						break;
					}
					std::string res;
					res = std::to_string(res_);
					stack.push(res);
				}
			}
			if (leksems[l] == ">=" ||
				leksems[l] == "<=" ||
				leksems[l] == ">" ||
				leksems[l] == "<" ||
				leksems[l] == "!=" ||
				leksems[l] == "=")
			{
				if (!stack.empty())
				{
					if (stack.top()[0] == '[')
					{
						std::istringstream in1;
						in1.str(stack.top());
						BigNumber temp2;
						in1 >> temp2;
						stack.pop();

						if (stack.top()[0] != '[')
							throw "Error: Arguments of differing types for operation on line ";

						std::istringstream in;
						in.str(stack.top());
						BigNumber temp1;
						in >> temp1;
						stack.pop();

						std::string res;
						bool res_;

						switch (leksems[l][0])
						{
						case '!':
							res_ = temp1 != temp2;
							break;
						case '=':
							res_ = temp1 == temp2;
							break;
						default:
							throw "Error: Incompatible type of arguments for operation on line ";
							break;
						}

						std::ostringstream out;
						out << res_;
						res = out.str();

						stack.push(res);
					}
					else
					{
						int temp2 = CharToInt(stack.top());
						stack.pop();

						if (stack.empty())
							throw "Error: Not enough arguments for operation on line ";
						if (stack.top()[0] == '[')
							throw "Error: Arguments of differing types for operation on line ";

						int temp1 = CharToInt(stack.top());
						stack.pop();

						std::string res;
						int res_;

						if (leksems[l] == "<=")
							res_ = temp1 <= temp2;
						else if (leksems[l] == ">=")
							res_ = temp1 >= temp2;
						else if (leksems[l] == "<")
							res_ = temp1 < temp2;
						else if (leksems[l] == ">")
							res_ = temp1 > temp2;
						else if (leksems[l] == "!=")
							res_ = temp1 != temp2;
						else
							res_ = temp1 == temp2;

						res = std::to_string(res_);
						stack.push(res);
					}
				}
				else
				{
					throw "Error: Empty stack on line ";
				}

				l++;
			}
			if (leksems[l] == "write")
			{
				if (!stack.empty())
				{
					if (stack.top()[0] == '[')
					{
						tempstr = stack.top();
						tempstr.erase(tempstr.begin());
					}
					else
						tempstr = stack.top();
					std::cout << tempstr << std::endl;
					stack.pop();
				}
			}
			if (leksems[l] == "read")
			{
				std::string var;
				std::getline(std::cin, var);
				std::string res;
				res = GetArg(var);
				stack.push(res);
			}
			if (leksems[l] == "digit")
			{
				std::istringstream g1;
				BigNumber func1;
				tempstr = stack.top();
				tempstr.erase(tempstr.begin());
				g1.str(tempstr);
				g1 >> func1;
				stack.pop();

				if (stack.top()[0] != '[')
					throw "Invalid arguments for operation on line ";

				std::istringstream g;
				tempstr = stack.top();
				tempstr.erase(tempstr.begin());
				g.str(tempstr);
				BigNumber func;
				g >> func;
				stack.pop();

				stringstream op;
				op << func.Get_digit(func1);
				op.str('[' + op.str());
				stack.push(op.str());
			}
			if (leksems[l] == "mns")
			{
				if (stack.top()[0] == '[')
				{
					std::istringstream g;
					tempstr = stack.top();
					tempstr.erase(tempstr.begin());
					g.str(tempstr);
					BigNumber func2;
					g >> func2;
					stack.pop();

					if (stack.top()[0] != '[')
						throw "Invalid argument type for operation on line ";

					std::istringstream g2;
					tempstr = stack.top();
					tempstr.erase(tempstr.begin());
					g2.str(tempstr);
					BigNumber func1;
					g2 >> func1;
					stack.pop();

					BigNumber res = func1 - func2;
					std::ostringstream tempo;
					tempo << res;
					tempo.str('[' + tempo.str());
					stack.push(tempo.str());
					l++;
				}
				else
					throw "Invalid arguments for operation of line ";
			}
			if (leksems[l] == "umn")
			{
				if (stack.top()[0] == '[')
				{
					std::istringstream g;
					tempstr = stack.top();
					tempstr.erase(tempstr.begin());
					g.str(tempstr);
					BigNumber func2;
					g >> func2;
					stack.pop();

					if (stack.top()[0] != '[')
						throw "Invalid argument type for operation on line ";

					std::istringstream g2;
					tempstr = stack.top();
					tempstr.erase(tempstr.begin());
					g2.str(tempstr);
					BigNumber func1;
					g2 >> func1;
					stack.pop();

					BigNumber res = func1 * func2;
					std::ostringstream tempo;
					tempo << res;
					tempo.str('[' + tempo.str());
					stack.push(tempo.str());
					l++;
				}
				else
					throw "Invalid arguments for operation of line ";
			}
			if (leksems[l] == "del")
			{
				if (stack.top()[0] == '[')
				{
					std::istringstream g;
					tempstr = stack.top();
					tempstr.erase(tempstr.begin());
					g.str(tempstr);
					BigNumber func2;
					g >> func2;
					stack.pop();

					if (stack.top()[0] != '[')
						throw "Invalid argument type for operation on line ";

					std::istringstream g2;
					tempstr = stack.top();
					tempstr.erase(tempstr.begin());
					g2.str(tempstr);
					BigNumber func1;
					g2 >> func1;
					stack.pop();

					BigNumber res = func1 / func2;
					std::ostringstream tempo;
					tempo << res;
					tempo.str('[' + tempo.str());
					stack.push(tempo.str());
					l++;
				}
				else
					throw "Invalid arguments for operation of line ";
			}
			if (leksems[l] == "mod")
			{
				if (stack.top()[0] == '[')
				{
					std::istringstream g;
					tempstr = stack.top();
					tempstr.erase(tempstr.begin());
					g.str(tempstr);
					BigNumber func2;
					g >> func2;
					stack.pop();

					if (stack.top()[0] != '[')
						throw "Invalid argument type for operation on line ";

					std::istringstream g2;
					tempstr = stack.top();
					tempstr.erase(tempstr.begin());
					g2.str(tempstr);
					BigNumber func1;
					g2 >> func1;
					stack.pop();

					BigNumber res = func1 % func2;
					std::ostringstream tempo;
					tempo << res;
					tempo.str('[' + tempo.str());
					stack.push(tempo.str());
					l++;
				}
				else
					throw "Invalid arguments for operation of line ";
			}
			if (leksems[l] == "plus")
			{
				if (stack.top()[0] == '[')
				{
					std::istringstream g;
					tempstr = stack.top();
					tempstr.erase(tempstr.begin());
					g.str(tempstr);
					BigNumber func2;
					g >> func2;
					stack.pop();

					if (stack.top()[0] != '[')
						throw "Invalid argument type for operation on line ";

					std::istringstream g2;
					tempstr = stack.top();
					tempstr.erase(tempstr.begin());
					g2.str(tempstr);
					BigNumber func1;
					g2 >> func1;
					stack.pop();

					BigNumber res = func1 + func2;
					std::ostringstream tempo;
					tempo << res;
					tempo.str('[' + tempo.str());
					stack.push(tempo.str());
					l++;
				}
				else
					throw "Invalid arguments for operation of line ";
			}
			if (leksems[l] == "end")
				l = leks + 1;
			else if (leksems[l] == "error")
				throw "Error: Invalid operation on line ";
			else if (leksems[l] == "\\n")
				i++;

			l++;
			temp.str("");
		}
	}
	catch (const char* err)
	{
		std::cout << err << i;
	}
}

std::vector<std::string> Analys(string filename, std::vector<std::string> keywords, int& l)
{
	FILE* fp = fopen("out.txt", "r");
	std::vector<std::string> leksems;
	char c = getc(fp);
	int type = 3;
	int j;
	int i;

	while (c != EOF)
	{
		//Создаём вектор в который будет записана лексема стоящая в начале строки
		std::string leks;
		i = 0;

		while (c == ' ') { c = getc(fp); }
		while (c != ' ' && c != '\n' && c != EOF)
		{
			leks.push_back(c);
			c = getc(fp);
			i++;
		}

		//Проверяем является ли лексема \n, EOF, ; или одним из ключевых слов
		//Если лексема является ; , то мы пропускаем всё что идет после неё
		if (i > 0)
		{
			bool ch = false;
			for (auto l : keywords)
			{
				if (leks == l)
					ch = true;
				else if (leks == ";")
				{
					leks = "\\n";
					ch = true;
					while (c != '\n' && c != EOF) { c = getc(fp); }
				}
			}

			if (!ch)
				leks = "error";
		}
		else if (c == '\n' || c == EOF)
		{
			if (c == '\n')
				leks = "\\n";
			else
				leks.push_back(c);
		}

		leksems.push_back(leks);

		//Определяем может ли что-то находится после лексемы помимо ; , \n и EOF
		//В зависимости от лексемы справа находится либо: 0 - переменная, 1 - переменная или константа, 2 - целое число
		if (leksems[l] == "pop")
			type = 0;

		if (leksems[l] == "push")
			type = 1;

		if (leksems[l] == "jmp" || leksems[l] == "ji")
			type = 2;

		l++;

		if (type >= 0 && type <= 2)
		{
			std::string param;
			i = 0;
			j = 0;

			while (c == ' ') { c = getc(fp); }

			//Проверяем параметер справа от лексемы
			if (c != '[')
			{
				while (c != ' ' && c != '\n' && c != EOF) { param.push_back(c); c = getc(fp); i++; }

				if (param[0] >= '0' && param[0] <= '9' && type == 2)
				{
					for (; j < i && param[j] >= '0' && param[j] <= '9'; j++) { ; }

					if (j != i)
					{
						param = "error";
					}
				}
				else if (type == 1)
				{
					if (param[0] >= '0' && param[0] <= '9')
						type = 2;
					else
						type = 1;

					for (; type = 2 && j < i && param[j] >= '0' && param[j] <= '9'; j++) { ; }

					bool ch;
					for (; j < i && type == 1; j++)
					{
						ch = (param[j] >= 'A' && param[j] <= 'Z') ||
							(param[j] >= 'a' && param[j] <= 'z') ||
							(param[j] >= '0' && param[j] <= '9') ||
							param[j] == '_';

						if (ch == 0)
						{
							param = "error";
							j = i;
						}
					}

					if (j != i && type == 2)
					{
						param = "error";
					}
				}
				else if (type == 0)
				{
					if (param[0] >= '0' && param[0] <= '9')
					{
						param = "error";
					}

					for (; j < i && type == 1; j++)
					{
						if ((param[j] >= 'A' && param[j] <= 'Z')
							|| (param[j] >= 'a' && param[j] <= 'z')
							|| (param[j] >= '0' && param[j] <= '9')
							|| param[j] == '_')
							;
						else
						{
							param = "error";
						}
					}
				}
				else
				{
					param = "error";
				}
			}
			else if (c == '[' && type == 1)
			{
				while (c != ' ' && c != '\n' && c != EOF) { param.push_back(c); c = getc(fp); i++; }
			}
			else { param = "error"; }

			leksems.push_back(param);
			l++;
		}

		//Пропускаем все пробелы, что идут дальше и убеждаемся, что в строке
		//больше ничего нет или оно отделенно ;
		while (c != ';' && c != '\n' && c != EOF && c == ' ') { c = getc(fp); }

		if (c == ';')
		{
			leksems.push_back("\\n");
			l++;
			while (c != '\n' && c != EOF) { c = getc(fp); }
		}
		else if (c != ';' && c != '\n' && c != EOF)
		{
			leksems.push_back("error");
			l++;
			while (c != '\n' && c != EOF) { c = getc(fp); }
		}

		if (c == EOF && leksems[l - 1] != "end")
		{
			leksems.push_back("error");
			l++;
		}

		//Отмечаем конец строки и переходим на следующую
		if (c == '\n')
		{
			if (leksems[l - 1] != "\\n")
			{
				leksems.push_back("\\n");
				l++;
			}
			c = getc(fp);
		}

		type = 3;
	}

	return leksems;
}

int main()
{
	//Создаём вектор ключевых слов
	std::vector<std::string> keywords;
	keywords.push_back("push");
	keywords.push_back("pop");
	keywords.push_back("throw");
	keywords.push_back("digit");
	keywords.push_back("umn");
	keywords.push_back("del");
	keywords.push_back("mod");
	keywords.push_back("plus");
	keywords.push_back("mns");
	keywords.push_back("+");
	keywords.push_back("-");
	keywords.push_back("*");
	keywords.push_back("/");
	keywords.push_back("%");
	keywords.push_back("<");
	keywords.push_back(">");
	keywords.push_back("<=");
	keywords.push_back(">=");
	keywords.push_back("=");
	keywords.push_back("!=");
	keywords.push_back("jmp");
	keywords.push_back("ji");
	keywords.push_back("write");
	keywords.push_back("read");
	keywords.push_back("end");


	/*OracleBuilder Or;
	Or.build_oracle("KS_gr_Zverev.txt");
	cout << Or << endl;*/
	bool _do = false;
	Synt syntax("eiler.txt", "KS_gr_Zverev.txt");
	if (syntax.Run())
		_do = true;
	if (_do)
	{
		//Создаём вектор лекскем, выделяем все лексемы в файле и выводим их
		std::vector<std::string> leksems;
		int n = 0;
		leksems = Analys("out.txt", keywords, n);

		/*for (auto i : leksems)
		{
			if (i == "\\n")
				cout << endl;
			else
				cout << i << " ";
		}*/

		//std::cout << std::endl;

		Interpret(keywords, leksems, n);
	}
}

// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.
