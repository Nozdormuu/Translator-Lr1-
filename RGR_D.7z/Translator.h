#pragma once
#include "Base.h"

class Translator
{
public:
	void Start(vector<Lexem_Token> leks, vector<vector<string>> exp, string filename)
	{
		line = 1;
		m_lexem = leks;
		m_exp = exp;
		temp_var = "switch";
		out.open(filename);
		DelDec();
		Translate();
		out << "end";
	}
	void DelDec()
	{
		int i = 0;
		while (m_lexem[i].m_type == "Var" && m_lexem[i + 2].m_type == "Type")
			m_lexem.erase(m_lexem.begin(), m_lexem.begin() + 4);
	}
	void Translate()
	{
		for (; pos < m_lexem.size(); pos++)
		{
			if (m_lexem[pos].m_leks == "od" || m_lexem[pos].m_leks == "else" || m_lexem[pos].m_leks == "fi"
				|| m_lexem[pos].m_leks == "case" || m_lexem[pos].m_leks == "otherwise" || m_lexem[pos].m_leks == "ni")
				break;
			if (m_lexem[pos].m_leks == "throw")
			{
				if (cycle_depth > trans_depth || if_depth > trans_depth || trans_depth)
					temp_out << "throw" << endl;
				else
					out << "throw" << endl;
				line++;
				pos++;

				continue;
			}
			if (m_lexem[pos].m_leks == ";")
			{
				if (cycle_depth > trans_depth || if_depth > trans_depth)
					break;

				continue;
			}
			if (m_lexem[pos].m_type == "Var")
			{
				TransLet();
				if (cycle_depth > trans_depth || if_depth > trans_depth)
					break;

				continue;
			}
			if (m_lexem[pos].m_leks == "while")
			{
				TransWhile();
				if (cycle_depth > trans_depth || if_depth > trans_depth)
					break;

				continue;
			}
			if (m_lexem[pos].m_leks == "for")
			{
				TransFor();
				if (cycle_depth > trans_depth || if_depth > trans_depth)
					break;

				continue;
			}
			if (m_lexem[pos].m_leks == "if")
			{
				TransIf();
				if (cycle_depth > trans_depth || if_depth > trans_depth)
					break;

				continue;
			}
			if (m_lexem[pos].m_leks == "select")
			{
				TransSwitch();
				if (cycle_depth > trans_depth || if_depth > trans_depth)
					break;

				continue;
			}
			if (m_lexem[pos].m_leks == "input")
			{
				TransLoad();
				if (cycle_depth > trans_depth || if_depth > trans_depth)
					break;

				continue;
			}
			if (m_lexem[pos].m_leks == "print")
			{
				TransPut();
				if (cycle_depth > trans_depth || if_depth > trans_depth)
					break;

				continue;
			}
			if (m_lexem[pos].m_type == "Label")
			{
				string mark;
				for (auto i : m_lexem[pos].m_leks)
					if (i != ':')
						mark.push_back(i);
				m_marks.push_back(pair<string, int>(mark, line));
				continue;
			}
			if (m_lexem[pos].m_leks == "jump")
			{
				pos++;
				for (auto i : m_marks)
					if (i.first == m_lexem[pos].m_leks)
						temp_out << "jmp " << i.second << endl;
				line++;
				pos++;
				if (!(cycle_depth > trans_depth || if_depth > trans_depth || trans_depth))
					out << temp_out.str();
				continue;
			}
		}
	}
private:
	void TransLet()
	{
		TransExp();
		exp_count++;
		temp_out << "pop " << m_lexem[pos].m_leks << endl;
		line++;
		pos += 3;
		if (!(trans_depth))
		{
			out << temp_out.str();
			temp_out.str("");
		}
	}

	void TransWhile()
	{
		stringstream temp_while;
		int while_start = line;
		TransExp();
		exp_count++;
		temp_while << temp_out.str();
		temp_out.str("");
		pos += 3;
		temp_while << "ji ";
		line++;
		trans_depth++;
		Translate();
		trans_depth--;
		temp_out << "jmp " << while_start << endl;
		line++;
		temp_while << line << endl;
		temp_while << temp_out.str();
		temp_out.str("");
		string temp = temp_while.str();
		temp_out.str("");
		if (cycle_depth > trans_depth || if_depth > trans_depth || trans_depth)
			temp_out << temp;
		else
			out << temp;
		pos++;
	}

	void TransFor()
	{
		stringstream temp_for;
		pos++;
		string var = m_lexem[pos].m_leks;
		TransExp();
		exp_count++;
		temp_out << "pop " << var << endl;
		line++;
		TransExp();
		exp_count++;
		temp_out << "pop " << temp_var << endl;
		line++;
		temp_for << temp_out.str();
		temp_out.str("");
		int for_start = line;
		temp_for << "push " << temp_var << endl;
		line++;
		temp_for << "push " << var << endl;
		line++;
		temp_for << "<" << endl;
		line++;
		pos += 5;
		bool for_step = false;
		int for_exp = exp_count;
		if (m_lexem[pos].m_leks == "by")
		{
			for_step = true;
			exp_count++;
		}
		temp_for << "ji ";
		line++;
		trans_depth++;
		Translate();
		trans_depth--;
		if (for_step)
		{
			int temp_exp = exp_count;
			exp_count = for_exp;
			TransExp();
			exp_count = temp_exp;
		}
		else
		{
			temp_out << "push " << temp_var << endl;
			line++;
			temp_out << "push " << temp_var << endl;
			line++;
			temp_out << "%" << endl;
			line++;
		}
		temp_out << "push " << var << endl;
		line++;
		temp_out << "+" << endl;
		line++;
		temp_out << "pop " << var << endl;
		line++;
		temp_out << "jmp " << for_start << endl;
		line++;
		temp_for << line << endl;
		temp_for << temp_out.str();
		temp_out.str("");
		string temp = temp_for.str();
		temp_for.str("");
		if (cycle_depth > trans_depth || if_depth > trans_depth || trans_depth)
			temp_out << temp;
		else
			out << temp;
	}

	void TransCase(string& temp)
	{
		stringstream temp_case;
		temp_case << "push " << temp_var << endl;
		line++;
		temp_case << "push " << m_lexem[pos].m_leks << endl;
		line++;
		temp_case << "=" << endl;
		line++;
		temp_case << "ji " << line + 2 << endl;
		line++;
		temp = temp_case.str();
		pos += 2;
	}

	void TransSwitch()
	{
		string temp_case;
		vector<string> _switch;
		stringstream temp_switch;
		pos += 4;
		TransExp();
		exp_count++;
		temp_switch << temp_out.str();
		temp_out.str("");
		temp_switch << "pop " << temp_var << endl;
		line++;
		TransCase(temp_case);
		temp_out << temp_case;
		temp_case.clear();
		temp_switch << temp_out.str();
		temp_out.str("");
		temp_switch << "jmp ";
		line++;
		
		trans_depth++;
		Translate();
		trans_depth--;
		temp_out << "jmp ";
		line++;
		temp_switch << line << endl;
		temp_switch << temp_out.str();
		temp_out.str("");
		_switch.push_back(temp_switch.str());
		temp_switch.str("");
		while (m_lexem[pos].m_leks == "case")
		{
			pos++;
			TransCase(temp_case);
			temp_out << temp_case;
			temp_case.clear();
			temp_switch << temp_out.str();
			temp_out.str("");
			temp_switch << "jmp ";
			line++;
			trans_depth++;
			Translate();
			trans_depth--;
			temp_out << "jmp ";
			line++;
			temp_switch << line << endl;
			temp_switch << temp_out.str();
			temp_out.str("");
			_switch.push_back(temp_switch.str());
			temp_switch.str("");
		}
		if (m_lexem[pos].m_leks == "otherwise")
		{
			pos++;
			trans_depth++;
			Translate();
			trans_depth--;
			temp_switch << temp_out.str();
			temp_out.str("");
		}
		stringstream temp;
		while (!_switch.empty())
		{
			temp.str(_switch.back() + to_string(line) + '\n');
			temp_switch.str(temp.str() + temp_switch.str());
			_switch.pop_back();
			temp.str("");
		}
		if (cycle_depth > trans_depth || if_depth > trans_depth || trans_depth)
			temp_out << temp_switch.str();
		else
			out << temp_switch.str();
		pos++;
	}

	void TransIf()
	{
		stringstream temp_if;
		TransExp();
		exp_count++;
		temp_if << temp_out.str();
		temp_out.str("");
		pos += 4;
		temp_if << "ji ";
		line++;
		trans_depth++;
		Translate();
		trans_depth--;
		if (m_lexem[pos].m_leks == "else")
		{
			temp_if << line + 1 << endl;
			temp_if << temp_out.str();
			temp_if << "jmp ";
			temp_out.str("");
			line++;
			pos++;
			trans_depth++;
			Translate();
			trans_depth--;
			temp_if << line << endl;
			temp_if << temp_out.str();
			temp_out.str("");
		}
		else
		{
			temp_if << line << endl;
			temp_if << temp_out.str();
			temp_out.str("");
		}
		string temp = temp_if.str();
		temp_if.str("");
		temp_out.str("");
		pos++;
		if (cycle_depth > trans_depth || if_depth > trans_depth || trans_depth)
			temp_out << temp;
		else
			out << temp;
	}

	void TransLoad()
	{
		pos++;
		temp_out << "read" << endl;
		line++;
		temp_out << "pop " << m_lexem[pos].m_leks << endl;
		line++;
		pos++;
		if (!(cycle_depth > trans_depth || if_depth > trans_depth || trans_depth))
		{
			out << temp_out.str();
			temp_out.str("");
		}
	}

	void TransPut()
	{
		stringstream temp_put;
		pos++;
		TransExp();
		exp_count++;
		temp_put << temp_out.str();
		temp_put << "write" << endl;
		temp_out.str("");
		line++;
		pos++;
		if (!(cycle_depth > trans_depth || if_depth > trans_depth || trans_depth))
			out << temp_put.str();
		else
			temp_out << temp_put.str();
	}

	void TransExp()
	{
		for (auto i : m_exp[exp_count])
		{
			if (i == "+" || i == "-" || i == "*" || i == "/" || i == "%" || i == "mns" || i == "plus" || i == "mod" || i == "del" || i == "umn" || i == "digit")
				temp_out << i << endl;
			else if (i == "<")
				temp_out << ">=" << endl;
			else if (i == ">")
				temp_out << "<=" << endl;
			else if (i == "<=")
				temp_out << ">" << endl;
			else if (i == ">=")
				temp_out << "<" << endl;
			else if (i == "==")
				temp_out << "!=" << endl;
			else if (i == "!=")
				temp_out << "=" << endl;
			else
				temp_out << "push " << i << endl;
			line++;
		}
	}
private:
	int pos = 0;
	int line = 1;
	int exp_count = 0;
	int trans_depth = 0;
	int cycle_depth = 0;
	int if_depth = 0;
	string temp_var;
	vector<pair<string, int>> m_marks;
	vector<Lexem_Token> m_lexem;
	vector<vector<string>> m_exp;
	stringstream temp_out;
	ofstream out;
};

