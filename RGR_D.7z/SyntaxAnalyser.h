#pragma once
#include "OracleBuilder.h"
#include "Translate.h"
#include "lexer.h"
#include <stack>
#include <string>
#include <vector>
#include <map>

using namespace std;




enum nonterminals
{
	S, program,declaration, declaration1, type, operators, label, step, expression, test, elseop, expression1, expression2,casess,cases,defualt,oper
};

enum terminals
{
	_$, _label, _semicolon, _variable, _twocolon, _eq, _while, _do, _od, _if, _lbr, _rbr, _fi, _input, _print, _jump, _comment, _throw, _else,
	_type, _ratio, _3prior, _2prior, _const, _1prior, _comma, _for, _from, _to, _by, _select,_in,_case,_ni,_otherwise
};

struct rule
{
	int nonterminal;
	int number;
	rule(int s, int n)
	{
		nonterminal = s;
		number = n;
	}
};

class Synt
{
   vector<Lexem_Token>::iterator it;
   vector<rule> rules;

   int syntTranslit(Lexem_Token l)
   {
      if (l.m_leks == "AR_OP")
      {
         return _2prior;
      }

      if (l.m_leks == "if")
      {
         return _if;
      }
      if (l.m_leks == "label")
      {
         return _label;
      }
      if (l.m_leks == "throw")
      {
         return _throw;
      }
      if (l.m_leks == "Constant")
      {
         return _const;
      }
      if (l.m_leks == "Var")
      {
         return _variable;
      }
      if (l.m_leks == "=")
      {
         return _eq;
      }
      if (l.m_leks == ":")
      {
         return _twocolon;
      }
      if (l.m_leks == ";")
      {
         return _semicolon;
      }
      if (l.m_leks == "while")
      {
         return _while;
      }
      if (l.m_leks == "if")
      {
         return _if;
      }
      if (l.m_leks == "do")
      {
         return _do;
      }
      if (l.m_leks == "od")
      {
         return _od;
      }
      if (l.m_leks == "Right_Br")
      {
         return _rbr;
      }
      if (l.m_leks == "Left_Br")
      {
         return _lbr;
      }
      if (l.m_leks == "fi")
      {
         return _fi;
      }
      if (l.m_leks == "input")
      {
         return _input;
      }
      if (l.m_leks == "print")
      {
         return _print;
      }
      if (l.m_leks == "jump")
      {
         return _jump;
      }
      if (l.m_leks == "<<<")
      {
         return _comment;
      }
      if (l.m_leks == "else")
      {
         return _else;
      }
      if ((l.m_leks == "int")or (l.m_leks == "BigNumber"))
      {
         return _type;
      }
      if (l.m_leks == "Order") {

         return _ratio; 
      }
      if (l.m_leks == "BigNumberOp") 
      {
         return _1prior;
      }
      if (l.m_leks == "for")
      {
         return _for;
      }
      if (l.m_leks == "from")
      {
         return _from;
      }
      if (l.m_leks == "to")
      {
         return _to;
      }
      if (l.m_leks == "by")
      {
         return _by;
      }
      if (l.m_leks == "select")
      {
         return _select;
      }
      if (l.m_leks == "in")
      {
         return _in;
      }
      if (l.m_leks == "case") 
      {
         return _case;
      }
      if (l.m_leks == "ni") {
         return _ni;
      }
      if (l.m_leks == "otherwise") 
      {
         return _otherwise;
      }



      
   }
      	
      
      	void shift(int n)
      	{
      		actions.push(n);
      		symbols.push(syntTranslit(*it));
      		it++;
      	}
      	void reduce(int n)
      	{
      		if (n == 0)
      		{
      			isAccepted = 1;
      			return;
      		}
      		if (rules[n].number >= actions.size() || rules[n].number >= symbols.size())
      		{
      			isAccepted = 0;
      			return;
      		}
      		for (int i = 0; i < rules[n].number; i++)
      		{
      			actions.pop();
      			symbols.pop();
      		}
      		symbols.push(rules[n].nonterminal);
      		if (builder.oracle.goto_table[actions.top()][symbols.top()].type == 2)
      			actions.push(builder.oracle.goto_table[actions.top()][symbols.top()].value);
      		else if (builder.oracle.goto_table[actions.top()][symbols.top()].type == 4) isAccepted = 0;
      	}
      	int isAccepted;
      public:
      	OracleBuilder builder;
      	
      
      Synt();
      	Synt(string programfile, string grammar) :  builder()
      	{
            filename = programfile;
      		rules.push_back(rule(S, 2));
      		rules.push_back(rule(declaration, 2));
      		rules.push_back(rule(declaration, 0));
            rules.push_back(rule(declaration1, 4));
      		rules.push_back(rule(type, 1));
      		rules.push_back(rule(label, 1));
            rules.push_back(rule(program, 0));
      		rules.push_back(rule(program, 2));
            rules.push_back(rule(operators, 1));
            rules.push_back(rule(operators, 4));
            rules.push_back(rule(operators, 5));
            rules.push_back(rule(operators, 11));
            rules.push_back(rule(step, 0));
            rules.push_back(rule(step, 2));
            rules.push_back(rule(operators, 8));
            rules.push_back(rule(elseop, 0));
            rules.push_back(rule(elseop, 2));
            rules.push_back(rule(operators, 2));
            rules.push_back(rule(operators, 0));
            rules.push_back(rule(operators, 3));
            rules.push_back(rule(operators, 2));
            rules.push_back(rule(operators, 3));
            rules.push_back(rule(operators, 2));
            rules.push_back(rule(operators, 7));
            rules.push_back(rule(casess, 2));
            rules.push_back(rule(casess, 0));
            rules.push_back(rule(casess, 1));
            rules.push_back(rule(cases, 4));
            rules.push_back(rule(defualt, 2));
      		rules.push_back(rule(test, 3));
      		rules.push_back(rule(expression, 3));
      		rules.push_back(rule(expression, 1));
      		rules.push_back(rule(expression1, 3));
      		rules.push_back(rule(expression1, 1));
      		rules.push_back(rule(expression2, 3));
      		rules.push_back(rule(expression2, 1));
      		rules.push_back(rule(expression2, 1));
            rules.push_back(rule(expression2, 6));
      		rules.push_back(rule(expression2, 4));
            rules.push_back(rule(operators, 7));
      
      		
      		builder.build_oracle(grammar);
      	}
      	bool Run()
      	{
            if (Translate(filename))
                return true;
            return false;
            int i = 0;
      		isAccepted = 2;
      		actions.push(0);
      		symbols.push(0);
            vector<Lexem_Token> lexer;
      		Lexem_Token l;
      		l.m_type = 228;
      		lexer.push_back(l);//�������� ������ - $
      		it = lexer.begin();
      		while (isAccepted == 2)//!(actions.top() == 0 && symbols.top() == )
      		{
      			
               if (it->m_leks == "error")
      					{
      						it++;
      						continue;
      					}
      			switch (builder.oracle.sr_table[actions.top()][syntTranslit(*it)].type)
      			{
      			case 0:
      				shift(builder.oracle.sr_table[actions.top()][syntTranslit(*it)].value);
                    i++;
      				break;
      			case 1:
      				reduce(builder.oracle.sr_table[actions.top()][syntTranslit(*it)].value);
      				break;
      			case 2:
      				break;
      			case 3:
      				isAccepted = 1;
      				break;
      			case 4:
      				isAccepted = 0;
                    cout << "Error in line " << lexer[i].m_line << endl;
      				break;
      			}
      		}
            return isAccepted;
      	}
      	stack <int> actions;
      	stack <int> symbols;
        string filename;
   };
